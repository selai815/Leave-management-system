<?php

global $name1;
function db_connection_close()
{
  global $connection;
  if(isset($connection))
  {
    mysqli_close($connection);
  }
}

function session()
{
	if (!(isset($_SESSION['empid']))) {

	header ("Location: index.php");

	}
}


function confirm_query($result_set) {
		if (!$result_set) {
			die("Database query failed.");
        }
}
function isHRAdminstrator()
{
	if ($_SESSION['rightid']== "2")
	{
		return true;
	}
	else 
	{
		return false;
	}
}
function checkuser(int $ar)
{
	if ($ar == 2)
	{
		$txt = "HR Administrator";
	}
	elseif ($ar == 3)
	{
		$txt = "Employee";
	}
	elseif ($ar == 4)
	{
		$txt = "HOD";
	}
	elseif ($ar == 5)
	{
		$txt = "General Manager";
	}
	else
	{
		$txt = "Invalid acccess";
	}
	return $txt;	
}
function escapeq($str) {
    return strtr($str, array(
        "\0" => "",
        "'"  => "&#39;",
        "\"" => "&#34;",
        "\\" => "&#92;",
        // more secure
        "<"  => "&lt;",
        ">"  => "&gt;",
    ));
}
function clean_it($selectstr)
{
	$selectstr = trim($selectstr);
	return $selectstr;
}

function checkinactivity(){
	if(time() - $_SESSION['timestamp'] > 420) { //set inactivity duration to 7 minutes max
			echo"<script>alert('15 Minutes over!');</script>";
			unset($_SESSION['empid'], $_SESSION['rightid'], $_SESSION['timestamp']);
			$_SESSION['logged_in'] = false;
			header("Location: ./index.php");
			exit;
	} 		
	else {
		$_SESSION['timestamp'] = time(); //set new timestamp
	}
}

function function_alert($message) { 
      
    // Display the alert box  
    echo "<script>alert('$message');</script>"; 
} 

/* Set the width of the side navigation to 250px */
/* Set the width of the side navigation to 250px and the left margin of the page content to 250px */

?>
		


