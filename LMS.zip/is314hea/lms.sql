-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 13, 2020 at 05:46 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `is314`
--

-- --------------------------------------------------------
DROP DATABASE IF EXISTS is314;

CREATE DATABASE is314;

USE is314;

--
-- Table structure for table `accessright`
--

DROP TABLE IF EXISTS `accessright`;
CREATE TABLE IF NOT EXISTS `accessright` (
  `accessright_id` int(11) NOT NULL AUTO_INCREMENT,
  `accessright_name` varchar(64) NOT NULL,
  `accessright_desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`accessright_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accessright`
--

INSERT INTO `accessright` (`accessright_id`, `accessright_name`, `accessright_desc`) VALUES
(2, 'HR Administrator', 'Administrate of HR information for employees'),
(3, 'Employee', 'Only apply for leaverequest and view leaverequest balance'),
(4, 'Head of Department', 'Approve leaverequest and view leaverequest reports'),
(5, 'General Manager', 'View Reports and approve HOD leaverequest'),
(6, 'System Administrator', 'Access all features of the system');

-- --------------------------------------------------------

--
-- Table structure for table `decision`
--

DROP TABLE IF EXISTS `decision`;
CREATE TABLE IF NOT EXISTS `decision` (
  `decision_id` int(11) NOT NULL AUTO_INCREMENT,
  `decision_name` varchar(64) NOT NULL,
  `decision_desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`decision_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `decision`
--

INSERT INTO `decision` (`decision_id`, `decision_name`, `decision_desc`) VALUES
(1, 'Approved', 'Approve to take leave as requested'),
(2, 'Pending', 'Need further discussion'),
(3, 'Not Approved', 'Leave request declined.'),
(4, 'Cancelled', 'Request cancelled by employee'),
(5, 'Not Viewed', 'Application not seen by approving officer ');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(255) NOT NULL,
  `department_desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `department_name`, `department_desc`) VALUES
(1, 'Human  Resource Management', 'Hr Stuff'),
(2, 'Finance and Audit', NULL),
(3, 'Sales and Marketing', NULL),
(4, 'Overall Management', 'General Managers Domain'),
(5, 'Restaurant', 'Cafeteria and Delicacies');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `userpassword` varchar(100) NOT NULL,
  `first_name` varchar(32) NOT NULL,
  `last_name` varchar(32) NOT NULL,
  `gender_id` int(11) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `date_hired` date NOT NULL,
  `contact_number` char(24) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `accessright_id` int(11) DEFAULT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`employee_id`),
  KEY `accessright_id` (`accessright_id`),
  KEY `post_id` (`post_id`),
  KEY `department_id` (`department_id`),
  KEY `supervisor_id` (`employee_id`),
  KEY `gender_id` (`gender_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `username`, `userpassword`, `first_name`, `last_name`, `gender_id`, `dob`, `date_hired`, `contact_number`, `email`, `accessright_id`, `supervisor_id`, `post_id`, `department_id`) VALUES
(1, 'tasi', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Tasi', 'Tuuhetoka', 2, '2001-10-13', '2020-01-01', '0225722098', 'watuuhetoka@gmail.com', 2, 8, 14, 1),
(2, 'lolohea', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Lolohea', 'Tuuhetoka', 1, '1984-03-15', '2018-05-01', '7746927', 'ltuuhetoka@gmail.com', 4, 3, 10, 2),
(3, 'jlopez', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Jennifer', 'Lopez', 1, '1982-08-01', '2020-05-01', '0225722098', 'jlopez@selena.com', 5, 3, 8, 4),
(4, 'kmajong', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Kathy', 'Mahjong', 1, '1985-05-05', '2020-02-05', '0225722098', 'majong@ymail.com', 4, 3, 10, 3),
(5, 'snoop', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Snoop', 'Dogg', 2, '1980-05-01', '2017-10-02', '0225722098', 'snoopy@gmail.com', 3, 4, 11, 3),
(6, 'cralph', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Caleb', 'Ralph', 2, '1986-04-01', '2020-07-02', '0225722098', 'caleb_ralph@gmail.com', 3, 2, 13, 1),
(7, 'sweed', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Sam', 'Weed', 2, '1974-03-01', '2020-01-02', '0225722098', 'sweed@gmail.com', 3, 8, 19, 1),
(8, 'crush', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Colen', 'Rush', 1, '1990-05-01', '2020-04-02', '0225722098', 'crush@supermarket6.co.fj', 4, 3, 10, 1),
(9, 'terepo', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Teresa', 'Terepo', 1, '1988-09-07', '2019-12-02', '0225722098', 'terepo@supermarket6.co.fj', 3, 2, 11, 2),
(10, 'sxing', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Shang', 'Xing', 2, '1980-01-01', '2020-03-01', '0225722098', 'sangsing@gmail.com', 3, 2, 13, 2),
(11, 'lousel', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Sharon', 'Louiesel', 1, '1976-04-01', '2015-01-01', '0225722098', 'lousel@gmail.com', 3, 8, 12, 1),
(12, 'moon', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Ban Kimono', 'Moon', 2, '1972-04-01', '2020-09-01', '0225722098', 'moon@gmail.com', 3, 4, 13, 3),
(13, 'kofi', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Kofi', 'Anaan', 2, '1989-04-01', '2020-01-01', '0225722098', 'kofiana@gmail.com', 3, 4, 20, 3),
(14, 'vunivalu', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Juliasi', 'Vunivalu', 2, '1992-04-01', '2019-12-31', '0225722098', 'vunivalu@gmail.com', 3, 4, 17, 3),
(15, 'smith', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Sam', 'Smith', 2, '1996-04-01', '2020-08-01', '0225722098', 'smith@supermarket6.co.fj', 3, 2, 11, 2),
(16, 'cramsay', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Gordon', 'Ramsay', 2, '1974-02-02', '2020-01-01', '0225722098', 'cramsay@supermarket6.co.fj', 3, 4, 16, 3),
(17, 'cfasi', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Christopher', 'Salt', 2, '1974-02-02', '2019-03-01', '0225722098', 'cfase@gmail.com', 3, 4, 15, 3),
(18, 'engmao', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Angela', 'Mao', 1, '1980-02-02', '2019-10-01', '0225722098', 'engmao@gmail.com', 3, 4, 17, 3),
(19, 'kumara', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Joseph', 'Kumara', 2, '1992-04-02', '2020-05-01', '0225722098', 'kumara@gmail.com', 3, 4, 7, 3),
(20, 'taro', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Casey', 'Tarotaro', 1, '1982-11-02', '2020-06-06', '0225722098', 'tarotaro@gmail.com', 3, 2, 7, 3),
(21, 'keni', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Keni', 'Togar', 2, '1981-05-05', '2020-01-01', '0225722098', 'keni@gmail.com', 6, 3, 21, 4),
(22, 'lomelo', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'Sam Kauona', 'Lomelo', 2, '1989-02-01', '2020-03-21', '0225444117', 'lomelo@gmail.com', 3, 8, 7, 1),
(23, 'rambo', '*B5A5B9B7364809F3FC2C9F10BCCD79155C71FB52', 'John', 'Rambo', 2, '1965-01-01', '2000-01-01', '02255544', 'rambo@gmail.com', 3, 4, 13, 3);

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

DROP TABLE IF EXISTS `gender`;
CREATE TABLE IF NOT EXISTS `gender` (
  `gender_id` int(11) NOT NULL AUTO_INCREMENT,
  `gender_name` varchar(64) NOT NULL,
  `gender_descc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`gender_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gender`
--

INSERT INTO `gender` (`gender_id`, `gender_name`, `gender_descc`) VALUES
(1, 'Female', NULL),
(2, 'Male', NULL),
(3, 'Others', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `leaverequest`
--

DROP TABLE IF EXISTS `leaverequest`;
CREATE TABLE IF NOT EXISTS `leaverequest` (
  `leaverequest_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `leavetype_id` int(11) NOT NULL,
  `application_date` date NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `totaldays` int(10) NOT NULL,
  `justification` varchar(255) DEFAULT NULL,
  `decision_id` int(10) NOT NULL DEFAULT '5',
  `decision_date` date DEFAULT NULL,
  `approvingofficer_id` int(11) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `files` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`leaverequest_id`),
  KEY `decision_id` (`decision_id`),
  KEY `approvingofficer_id` (`approvingofficer_id`),
  KEY `leavetype_id` (`leavetype_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leaverequest`
--

INSERT INTO `leaverequest` (`leaverequest_id`, `employee_id`, `leavetype_id`, `application_date`, `startdate`, `enddate`, `totaldays`, `justification`, `decision_id`, `decision_date`, `approvingofficer_id`, `comments`, `files`) VALUES
(1, 10, 1, '2020-04-01', '2020-04-03', '2020-04-03', 1, NULL, 1, '2020-10-28', 2, '', NULL),
(2, 10, 1, '2020-05-11', '2020-05-18', '2020-05-18', 1, NULL, 1, '2020-05-16', 2, NULL, NULL),
(3, 10, 1, '2020-07-09', '2020-07-15', '2020-07-15', 1, NULL, 1, '2020-11-05', 2, '', NULL),
(4, 12, 5, '2020-06-01', '2020-07-08', '2020-07-12', 5, NULL, 1, '2020-06-01', 2, NULL, NULL),
(5, 13, 5, '2020-07-01', '2020-07-01', '2020-07-03', 3, NULL, 1, '2020-07-01', 4, NULL, NULL),
(6, 13, 5, '2020-07-13', '2020-07-16', '2020-07-17', 2, NULL, 1, '2020-07-14', 4, NULL, NULL),
(7, 4, 5, '2020-04-01', '2020-04-14', '2020-04-16', 3, NULL, 1, '2020-04-06', 3, NULL, NULL),
(8, 10, 1, '2019-11-01', '2019-11-05', '2019-11-05', 1, 'See Doctor', 1, '2019-11-02', 8, 'Work is fine with this leaverequest', NULL),
(10, 1, 4, '2020-10-27', '2020-10-20', '2020-10-21', 2, 'Hahahahahahaha', 1, '2020-10-19', 8, NULL, NULL),
(27, 1, 1, '2020-10-27', '2020-11-01', '2020-11-01', 1, 'Walkka Wakka', 1, '2020-11-10', 8, '', NULL),
(12, 1, 5, '2020-10-27', '2020-10-30', '2020-10-30', 1, 'Funeral', 1, '2020-11-10', 8, '', NULL),
(14, 2, 5, '2020-10-27', '2020-10-14', '2020-10-15', 2, 'Go to Queenstown', 5, NULL, 3, NULL, NULL),
(15, 7, 5, '2020-10-27', '2020-10-28', '2020-10-29', 2, 'Sweet Honeymoon', 1, '2020-11-10', 8, '', NULL),
(28, 2, 1, '2020-10-27', '2020-10-28', '2020-10-28', 1, 'GO TO Airport', 2, NULL, 3, NULL, NULL),
(30, 20, 4, '2020-10-27', '2020-10-01', '2020-10-30', 30, 'New member of the family.', 1, '2020-10-28', 4, '', NULL),
(31, 20, 3, '2020-10-27', '2020-10-31', '2020-11-07', 8, 'Recover Properly', 1, '2020-10-28', 4, '', NULL),
(32, 20, 1, '2020-10-27', '2020-09-24', '2020-09-24', 1, 'Urgent matter', 2, '2020-10-28', 4, '', NULL),
(33, 19, 2, '2020-10-27', '2020-09-02', '2020-09-03', 2, 'Waikiki Tamure', 4, '2020-09-02', 4, NULL, NULL),
(34, 19, 1, '2020-10-27', '2020-10-28', '2020-10-28', 1, 'Welcome to King Taro', 1, '2020-10-28', 4, '', NULL),
(35, 1, 1, '2020-10-27', '2020-11-05', '2020-11-05', 1, 'Going on a date', 1, '2020-11-10', 8, '', NULL),
(36, 10, 2, '2020-10-28', '2020-11-02', '2020-11-03', 2, 'Great Uncle Passed', 1, '2020-11-05', 2, 'Need To Talk with the officer on who is going to substitute', NULL),
(37, 12, 1, '2020-10-28', '2020-10-30', '2020-10-30', 1, 'Hhhhhhahahahahaha', 1, '2020-11-05', 2, '', NULL),
(38, 12, 5, '2020-10-28', '2020-11-02', '2020-11-03', 2, 'HAppy Holiday', 1, '2020-10-28', 2, 'Blah Blah Blah', NULL),
(39, 15, 5, '2020-10-28', '2020-11-05', '2020-11-06', 2, 'Time For Holiday', 1, '2020-10-29', 2, '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `leavetype`
--

DROP TABLE IF EXISTS `leavetype`;
CREATE TABLE IF NOT EXISTS `leavetype` (
  `leavetype_id` int(11) NOT NULL AUTO_INCREMENT,
  `leavetype_name` varchar(32) NOT NULL,
  `full_entitlement` int(11) NOT NULL,
  PRIMARY KEY (`leavetype_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leavetype`
--

INSERT INTO `leavetype` (`leavetype_id`, `leavetype_name`, `full_entitlement`) VALUES
(1, 'Casual Leave', 3),
(2, 'Bereavement', 2),
(3, 'Sick', 6),
(4, 'Maternity', 20),
(5, 'Vacation', 10);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
CREATE TABLE IF NOT EXISTS `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_name` varchar(255) NOT NULL,
  `post_desc` mediumtext,
  `salary_level` int(11) DEFAULT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `post_name`, `post_desc`, `salary_level`) VALUES
(7, 'Driver', 'Driving and Keeping the passenger safe', 10),
(8, 'General Manager', 'Owner of the Company', 1),
(9, 'Sales person', 'sell products to the products', 7),
(10, 'Head of Department', 'oversees the business operation', 2),
(11, 'Accountant', ' performs financial functions', 4),
(12, 'Benefits Officer', 'Counsels and advises employees and retirees on retirement benefit information', 4),
(13, 'Clerk', 'Counsels and advises employees and retirees on retirement benefit information', 9),
(14, 'IT Officer', 'Counsels and advises employees and retirees on retirement benefit information', 5),
(15, 'Salesman', 'Work at supermarket', 7),
(16, 'Chef', 'Head of Cafe Kitchen', 5),
(17, 'Sanitation Officer', 'Markets', 10),
(18, 'Secretary', 'General managers personal secretary', 5),
(19, 'HR Officer', 'Work With HR division', 3),
(20, 'Cook', 'Works in Kithcenth', 8),
(21, 'System Administrator', 'Head of ICT unit Oversee ICT infrastructure', 4),
(22, 'Data Entry Class 1', 'Enter Sales Data', 7);

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE IF NOT EXISTS `status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(255) NOT NULL,
  `status_desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`status_id`, `status_name`, `status_desc`) VALUES
(1, 'Active', 'Serving employee'),
(2, 'Inactive', 'No longer employed');

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_daysworked`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `vi_daysworked`;
CREATE TABLE IF NOT EXISTS `vi_daysworked` (
`DaysWorked` int(9)
,`employee_id` int(11)
,`employeename` varchar(65)
,`date_hired` date
,`leavetype_id` int(11)
,`leavetype_name` varchar(32)
,`full_entitlement` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_earnedleave`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `vi_earnedleave`;
CREATE TABLE IF NOT EXISTS `vi_earnedleave` (
`GrossEntitlement` bigint(14)
,`employee_id` int(11)
,`employeename` varchar(65)
,`leavetype_id` int(11)
,`leavetype_name` varchar(32)
,`full_entitlement` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_employee`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `vi_employee`;
CREATE TABLE IF NOT EXISTS `vi_employee` (
`employee_id` int(11)
,`first_name` varchar(32)
,`last_name` varchar(32)
,`gender_id` int(11)
,`gender_name` varchar(64)
,`dob` date
,`date_hired` date
,`contact_number` char(24)
,`email` varchar(64)
,`accessright_id` int(11)
,`accessright_name` varchar(64)
,`post_id` int(11)
,`post_name` varchar(255)
,`department_id` int(11)
,`department_name` varchar(255)
,`supervisor_id` int(11)
,`ReportsTo` varchar(65)
,`username` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_leavebalance`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `vi_leavebalance`;
CREATE TABLE IF NOT EXISTS `vi_leavebalance` (
`LeaveBalance` decimal(33,0)
,`GrossEntitlement` bigint(14)
,`LeaveTaken` decimal(32,0)
,`employee_id` int(11)
,`employeename` varchar(65)
,`leavetype_id` int(11)
,`leavetype_name` varchar(32)
,`full_entitlement` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_leaverequest`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `vi_leaverequest`;
CREATE TABLE IF NOT EXISTS `vi_leaverequest` (
`leaverequest_id` int(11)
,`employee_id` int(11)
,`employeename` varchar(65)
,`application_date` date
,`leavetype_id` int(11)
,`leavetype_name` varchar(32)
,`startdate` date
,`enddate` date
,`totaldays` int(10)
,`justification` varchar(255)
,`decision_id` int(10)
,`decision_name` varchar(64)
,`decision_date` date
,`comments` varchar(255)
,`approvingofficer_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_leavetaken`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `vi_leavetaken`;
CREATE TABLE IF NOT EXISTS `vi_leavetaken` (
`employee_id` int(11)
,`employeename` varchar(65)
,`leavetype_id` int(11)
,`totaldays` decimal(32,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_maxleave`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `vi_maxleave`;
CREATE TABLE IF NOT EXISTS `vi_maxleave` (
`employee_id` int(11)
,`employeename` varchar(65)
,`leavetype_id` int(11)
,`leavetype_name` varchar(32)
,`full_entitlement` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_tourofservice`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `vi_tourofservice`;
CREATE TABLE IF NOT EXISTS `vi_tourofservice` (
`TourofServiceStart` date
,`employee_id` int(11)
,`employeename` varchar(65)
,`date_hired` date
,`leavetype_id` int(11)
,`leavetype_name` varchar(32)
,`full_entitlement` int(11)
);

-- --------------------------------------------------------

--
-- Structure for view `vi_daysworked`
--
DROP TABLE IF EXISTS `vi_daysworked`;

DROP VIEW IF EXISTS `vi_daysworked`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_daysworked`  AS  select floor((to_days(curdate()) - to_days(if((year(`employee`.`date_hired`) >= year(now())),`employee`.`date_hired`,makedate(year(now()),1))))) AS `DaysWorked`,`vi_maxleave`.`employee_id` AS `employee_id`,`vi_maxleave`.`employeename` AS `employeename`,`employee`.`date_hired` AS `date_hired`,`vi_maxleave`.`leavetype_id` AS `leavetype_id`,`vi_maxleave`.`leavetype_name` AS `leavetype_name`,`vi_maxleave`.`full_entitlement` AS `full_entitlement` from (`vi_maxleave` join `employee` on((`vi_maxleave`.`employee_id` = `employee`.`employee_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_earnedleave`
--
DROP TABLE IF EXISTS `vi_earnedleave`;

DROP VIEW IF EXISTS `vi_earnedleave`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_earnedleave`  AS  select if((if((`vi_daysworked`.`leavetype_id` = 5),floor((`vi_daysworked`.`DaysWorked` / 30)),if((`vi_daysworked`.`leavetype_id` = 3),(floor((`vi_daysworked`.`DaysWorked` / 30)) * 2),`vi_daysworked`.`full_entitlement`)) >= `vi_daysworked`.`full_entitlement`),`vi_daysworked`.`full_entitlement`,if((`vi_daysworked`.`leavetype_id` = 5),floor((`vi_daysworked`.`DaysWorked` / 30)),if((`vi_daysworked`.`leavetype_id` = 3),(floor((`vi_daysworked`.`DaysWorked` / 30)) * 2),`vi_daysworked`.`full_entitlement`))) AS `GrossEntitlement`,`vi_daysworked`.`employee_id` AS `employee_id`,`vi_daysworked`.`employeename` AS `employeename`,`vi_daysworked`.`leavetype_id` AS `leavetype_id`,`vi_daysworked`.`leavetype_name` AS `leavetype_name`,`vi_daysworked`.`full_entitlement` AS `full_entitlement` from `vi_daysworked` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_employee`
--
DROP TABLE IF EXISTS `vi_employee`;

DROP VIEW IF EXISTS `vi_employee`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_employee`  AS  select `a`.`employee_id` AS `employee_id`,`a`.`first_name` AS `first_name`,`a`.`last_name` AS `last_name`,`a`.`gender_id` AS `gender_id`,`gender`.`gender_name` AS `gender_name`,`a`.`dob` AS `dob`,`a`.`date_hired` AS `date_hired`,`a`.`contact_number` AS `contact_number`,`a`.`email` AS `email`,`a`.`accessright_id` AS `accessright_id`,`accessright`.`accessright_name` AS `accessright_name`,`a`.`post_id` AS `post_id`,`post`.`post_name` AS `post_name`,`a`.`department_id` AS `department_id`,`department`.`department_name` AS `department_name`,`a`.`supervisor_id` AS `supervisor_id`,concat(`b`.`first_name`,' ',`b`.`last_name`) AS `ReportsTo`,`a`.`username` AS `username` from ((((`gender` join `post`) join `department`) join `accessright`) join (`employee` `a` left join `employee` `b` on((`a`.`supervisor_id` = `b`.`employee_id`)))) where ((`accessright`.`accessright_id` = `a`.`accessright_id`) and (`post`.`post_id` = `a`.`post_id`) and (`department`.`department_id` = `a`.`department_id`) and (`gender`.`gender_id` = `a`.`gender_id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_leavebalance`
--
DROP TABLE IF EXISTS `vi_leavebalance`;

DROP VIEW IF EXISTS `vi_leavebalance`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_leavebalance`  AS  select (`vi_earnedleave`.`GrossEntitlement` - ifnull(`vi_leavetaken`.`totaldays`,0)) AS `LeaveBalance`,`vi_earnedleave`.`GrossEntitlement` AS `GrossEntitlement`,ifnull(`vi_leavetaken`.`totaldays`,0) AS `LeaveTaken`,`vi_earnedleave`.`employee_id` AS `employee_id`,`vi_earnedleave`.`employeename` AS `employeename`,`vi_earnedleave`.`leavetype_id` AS `leavetype_id`,`vi_earnedleave`.`leavetype_name` AS `leavetype_name`,`vi_earnedleave`.`full_entitlement` AS `full_entitlement` from (`vi_earnedleave` left join `vi_leavetaken` on(((`vi_earnedleave`.`employee_id` = `vi_leavetaken`.`employee_id`) and (`vi_earnedleave`.`leavetype_id` = `vi_leavetaken`.`leavetype_id`)))) order by `vi_earnedleave`.`employee_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_leaverequest`
--
DROP TABLE IF EXISTS `vi_leaverequest`;

DROP VIEW IF EXISTS `vi_leaverequest`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_leaverequest`  AS  select `leaverequest`.`leaverequest_id` AS `leaverequest_id`,`employee`.`employee_id` AS `employee_id`,concat(`employee`.`first_name`,' ',`employee`.`last_name`) AS `employeename`,`leaverequest`.`application_date` AS `application_date`,`leaverequest`.`leavetype_id` AS `leavetype_id`,`leavetype`.`leavetype_name` AS `leavetype_name`,`leaverequest`.`startdate` AS `startdate`,`leaverequest`.`enddate` AS `enddate`,`leaverequest`.`totaldays` AS `totaldays`,`leaverequest`.`justification` AS `justification`,`leaverequest`.`decision_id` AS `decision_id`,`decision`.`decision_name` AS `decision_name`,`leaverequest`.`decision_date` AS `decision_date`,`leaverequest`.`comments` AS `comments`,`leaverequest`.`approvingofficer_id` AS `approvingofficer_id` from ((`leavetype` join `employee`) join (`leaverequest` left join `decision` on((`leaverequest`.`decision_id` = `decision`.`decision_id`)))) where ((`employee`.`employee_id` = `leaverequest`.`employee_id`) and (`leavetype`.`leavetype_id` = `leaverequest`.`leavetype_id`)) order by `leaverequest`.`startdate` desc ;

-- --------------------------------------------------------

--
-- Structure for view `vi_leavetaken`
--
DROP TABLE IF EXISTS `vi_leavetaken`;

DROP VIEW IF EXISTS `vi_leavetaken`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_leavetaken`  AS  select `employee`.`employee_id` AS `employee_id`,concat(`employee`.`first_name`,' ',`employee`.`last_name`) AS `employeename`,`leaverequest`.`leavetype_id` AS `leavetype_id`,sum(`leaverequest`.`totaldays`) AS `totaldays` from (`employee` left join `leaverequest` on((`employee`.`employee_id` = `leaverequest`.`employee_id`))) where ((year(`leaverequest`.`startdate`) = year(curdate())) and (`leaverequest`.`decision_id` = 1)) group by `employee`.`employee_id`,`leaverequest`.`leavetype_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_maxleave`
--
DROP TABLE IF EXISTS `vi_maxleave`;

DROP VIEW IF EXISTS `vi_maxleave`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_maxleave`  AS  select `employee`.`employee_id` AS `employee_id`,concat(`employee`.`first_name`,' ',`employee`.`last_name`) AS `employeename`,`leavetype`.`leavetype_id` AS `leavetype_id`,`leavetype`.`leavetype_name` AS `leavetype_name`,`leavetype`.`full_entitlement` AS `full_entitlement` from (`employee` join `leavetype`) order by `employee`.`employee_id`,`leavetype`.`leavetype_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_tourofservice`
--
DROP TABLE IF EXISTS `vi_tourofservice`;

DROP VIEW IF EXISTS `vi_tourofservice`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_tourofservice`  AS  select if((year(`employee`.`date_hired`) >= year(now())),`employee`.`date_hired`,makedate(year(now()),1)) AS `TourofServiceStart`,`vi_maxleave`.`employee_id` AS `employee_id`,`vi_maxleave`.`employeename` AS `employeename`,`employee`.`date_hired` AS `date_hired`,`vi_maxleave`.`leavetype_id` AS `leavetype_id`,`vi_maxleave`.`leavetype_name` AS `leavetype_name`,`vi_maxleave`.`full_entitlement` AS `full_entitlement` from (`vi_maxleave` join `employee` on((`vi_maxleave`.`employee_id` = `employee`.`employee_id`))) ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
