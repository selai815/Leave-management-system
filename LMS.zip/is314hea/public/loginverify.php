<?php  
	require("../includes/db_connection.php");
	session_start();
 
if (isset($_POST['username']) and isset($_POST['password'])){
	
	// Assigning POST values to variables.
	$username = $_POST['username'];
	$password = $_POST['password'];

	// CHECK FOR THE RECORD FROM TABLE
	$query = "SELECT * FROM `employee` WHERE username='$username' and userpassword= PASSWORD('$password')";
 
	$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
	$count = mysqli_num_rows($result);

	if ($count == 1){
		// get the employee details out
		$row = mysqli_fetch_assoc($result);
		$_SESSION['empid'] = $row['employee_id'];
		$_SESSION['rightid'] = $row['accessright_id'];
		$_SESSION['fname'] = $row['first_name'];
		$_SESSION['lname'] = $row['last_name'];
		$_SESSION['timestamp'] = time(); 
		$_SESSION['logged_in'] = True;
		
		if ($_SESSION["rightid"] == 2)
		{
			$_SESSION['navifile'] =  "src/layout/hradminsidenavi.php"; 
		}
		elseif ($_SESSION["rightid"] == 3)
		{
			$_SESSION['navifile'] =  "src/layout/empsidenavi.php"; 
		}
		elseif ($_SESSION["rightid"] == 4)
		{
			$_SESSION['navifile'] = "src/layout/hodsidenavi.php"; 
		}
		elseif ($_SESSION["rightid"] == 5)
		{
			$_SESSION['navifile'] = "src/layout/gmsidenavi.php"; 
		}
		else
		{
			$_SESSION['navifile'] = "src/layout/itadminsidenavi.php"; 
		}
		
		header("Location: ./welcome.php");
		exit;
		
	}
	else{
		// go back to login form
		header("Location: ./loginfail.php");
		// stop this script here
		exit;
	}
	db_connection_close();
}
?>

