<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	
	checkinactivity();
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
		
	</head>
<?php 
		
	// include the file that defines (contains) the username and password
	require_once("../includes/db_connection.php");
	//connect to your mysql database
	
	//Retrieve leave data for employees under the user's responsibility
	//check if user entered date range and clicked the search button
	if (isset($_POST['search']))
	{
		$accessrightid = $_POST['accessrightid'];
		$query = "SELECT * FROM vi_employee WHERE accessright_id = '$accessrightid' ORDER BY accessright_id, last_name";
	}
	else if (isset($_POST['showall']))
	{
		
		$query = "SELECT * FROM vi_employee ORDER BY accessright_id, last_name";
	}
	else
	{
		$query = "SELECT * FROM vi_employee ORDER BY accessright_id, last_name";
	}
		
	$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
	//$row = mysqli_fetch_assoc($result);
?>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	
	<div class = "maincontent">
		<h2>System Users</h2>
		<form method = "post"><table>
		<tr><td>Access Rights: <select size="1" name="accessrightid">
			<?php 
				$leavetype = mysqli_query($connection, "SELECT * from accessright") or die(mysqli_error($connection));
				while ($line = mysqli_fetch_array($leavetype, MYSQLI_ASSOC)) 
				{ 
					echo "<option value='" . $line['accessright_id'] . "'>"; 
					echo $line['accessright_name'] . "</option>"; 
				} 
			?>
		</td><td><input type="submit" name="search" value="Run Query" style="hover: pointer;"></td><td><input type="submit" name="showall" value="Report All" style="hover: pointer;"></td></tr></table>
		<table class="table" id="tblform">
			<tr>
				<td><a><b>Count.</b></b></td>
				<td><a><b>Employee Name & No.</b></b></td>
				<td><a><b>Post</b></a></td>
				<td><a><b>Department</b></a></td>
				<td><a><b>Access Right ID</b></a></td>
				<td><a><b>Access Right</b></a></td>
			</tr>
			<?php
				$i = 0;
				$mess = "No record found!";				
				if($result->num_rows > 0){
					while ($line=mysqli_fetch_assoc($result)){
						echo "<tr><center>";
						echo "<td>".($i+1). "</td>";
						echo "<td>".$line['last_name'].", ". $line['first_name']." (".$line['employee_id'].")"."</td>";
						echo "<td>".$line['post_name']."</td>";
						echo "<td>".$line['department_name']."</td>";
						echo "<td>".$line['accessright_id']."</td>";
						echo "<td>".$line['accessright_name']."</td>";
						echo "</center></tr>";
						$i++;	
					}
				}
				else
				{					
					echo "<tr><td>". $mess . "</td></tr>";
				}	
				db_connection_close();	
			?>
			</tbody>
			</table>
	
	<button id="btnExportToCSV" type="button" class="button">Export to CSV</button>
	<script src="src/js/TableCSVExporter.js"></script>
	<script> 
		const dataTable = document.getElementById("tblform");
		const btnExportToCSV = document.getElementById("btnExportToCSV");
		
		btnExportToCSV.addEventListener("click", () => {
			alert("Hello World");
			const exporter =  new TableCSVExporter(dataTable);
			const csvOutput =  exporter.convertToCSV();
			const csvBlob = new Blob([csvOutput], { type: "text/csv"});
			const blobUrl - URL.createObjectURL(csvBlob);
			
		});
		
	</script>
	</div>
	</body>
</html>

