<?php  
	
	session_start();
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	
	session();
	
	checkinactivity();

?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
		        
	</head>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
	</div>
	<body>
		<?php 
			include_once($_SESSION['navifile']);
		?>
		<div class = "maincontent">		
		<?php	
			// Assigning POST values to variables.
			$employeeid = $_POST['empnum'];
			$firstname = escapeq(clean_it($_POST['firstname']));
			$lastname = escapeq(clean_it($_POST['lastname']));
			$genderid = $_POST['genderid'];
			$dob = clean_it($_POST['dob']);
			$datehired = clean_it($_POST['datehired']);
			$contactno = escapeq(clean_it($_POST['contactnumber']));
			$email = escapeq(clean_it($_POST['email']));
			$postid = $_POST['postid'];
			$departmentid = $_POST['departmentid'];
			$accessrightid = $_POST['accessrightid'];
			$username = escapeq(clean_it($_POST['username']));
			// Insert query
			$supervisorid = "";
			if ($departmentid != 4){  //CHECK IF division is not iverall management 
				
				$query1 = "SELECT employee_id FROM employee WHERE department_id = '$departmentid' AND post_id = 10"; 
				$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
				$row1 = mysqli_fetch_assoc($result1);
				$count = mysqli_num_rows($result1);
				if ($count == 1){
					$supervisorid = $row1['employee_id'];
				}
				else{
					$query1 = "SELECT employee_id FROM employee WHERE post_id = 8"; 
					$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
					$row1 = mysqli_fetch_assoc($result1);
					$supervisorid = $row1['employee_id'];
				}
			}
			else{
				
				$query1 = "SELECT employee_id FROM employee WHERE post_id = 8"; 
				$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
				$row1 = mysqli_fetch_assoc($result1);
				$supervisorid = $row1['employee_id'];
			}
			
			$query = "UPDATE employee SET first_name = '$firstname', last_name = '$lastname', gender_id = '$genderid', dob ='$dob', date_hired='$datehired',
			contact_number='$contactno', email = '$email', accessright_id = '$accessrightid', supervisor_id = '$supervisorid', post_id='$postid', department_id = '$departmentid',
			username = '$username' WHERE employee_id = '$employeeid'";
	
			$added = mysqli_query($connection, $query) or die(mysqli_error($connection));
		
			// report results
			if(!$added)
			{
				echo mysqli_error($connection);
			}
			else
			{
				echo "<center><b>"."Employee updated successfully." . "</center></b><br>"; 
				//mail($email, $mailsubject, $mailbody); 
				//echo "<script type= 'text/javascript'>alert('Your application has been sent to your supervisor');</script>";
			}
			db_connection_close();	
		?>
		</div>
	</body>
</html>


