<?php  
	
	session_start();
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	
	session();
	
	checkinactivity();

?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
		        
	</head>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
	</div>
	<body>
		<?php 
			include_once($_SESSION['navifile']);
		?>
		<div class = "maincontent">		
		<?php	
			// Assigning POST values to variables.
			$oldpassword=escapeq(clean_it($_POST['oldpassword']));
			$newpassword=escapeq(clean_it($_POST['newpassword']));
			$newpasswordcon=escapeq(clean_it($_POST['newpasswordconfirm']));
			
			// build query using salt to password 
			
			$query1 = "SELECT employee_id, first_name, last_name from employee WHERE employee_id = '".$_SESSION['empid']."' AND userpassword = PASSWORD('$oldpassword')"; 			
			$compare = mysqli_query($connection, $query1) or die(mysqli_error($connection));
			$count = mysqli_num_rows($compare);
			if ($count > 0)
			{
				if ($newpassword == $newpasswordcon)
				{
					$updated = mysqli_query($connection, "UPDATE employee SET userpassword = PASSWORD('$newpassword') WHERE employee_id ='".$_SESSION['empid']."'") or die(mysqli_error($connection));
					if(!$updated)
					{
						echo mysqli_error($connection);
					}
					else
					{
						echo "<center><b>"."PASSWORD SUCCESSFULLY CHANGED.". "</center></b><br>"; 
					}
				}
				else
				{
					echo "<center><b>"."NEW PASSWORD NOT MATCH!!!". "</center></b><br>"; 
					//header("Location: ./passwordmineresetform.php");
					//exit;
				}
			}
			else
			{
				// go back to login form
					echo "<center><b>"."OLD PASSWORD INVALID!!!". "</center></b><br>";
					//header("Location: ./passwordmineresetform.php");
				// stop this script here
				//exit;
			}
		?>
			<table><tr><td></td></tr>
			<center><form action="passwordmineresetform.php"><input type="submit" style="font-size: 22px;" value="BACK"/></form></center></table>
		</div>
	</body>
</html>


