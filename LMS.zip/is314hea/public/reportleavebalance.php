<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	
	checkinactivity();
	
	$empnum = $_SESSION['empid'];
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
		
	</head>
<?php 
		
	// include the file that defines (contains) the username and password
	require_once("../includes/db_connection.php");
	//connect to your mysql database
	
	//checking if general manager
	$qry ="Select post_id from vi_employee WHERE employee_id='$empnum'";
	$res = mysqli_query($connection, $qry) or die(mysqli_error($connection));
	$row = mysqli_fetch_assoc($res);
	
	if ($row['post_id'] != 8){  //CHECK IF USER IS GENERAL MANAGER
	//Retrieve leave data for employees under the user's responsibility
	//check if user entered date range and click search button
		if (isset($_POST['search']))
		{
			$leavetypeid = $_POST['leavetypeid'];
			$query = "SELECT vi_leavebalance.*, supervisor_id FROM vi_leavebalance, employee WHERE employee.employee_id = vi_leavebalance.employee_id AND leavetype_id = '$leavetypeid' AND
			employee.supervisor_id = '".$_SESSION['empid']."' ORDER BY vi_leavebalance.employee_id ASC, leavetype_id DESC";
		}
		else if (isset($_POST['showall']))
		{
		
			$query = "SELECT vi_leavebalance.*, supervisor_id FROM vi_leavebalance, employee WHERE employee.employee_id = vi_leavebalance.employee_id AND employee.supervisor_id = '".$_SESSION['empid']."' 
			ORDER BY vi_leavebalance.employee_id ASC, leavetype_id DESC";
		}
		else
		{
			$query = "SELECT vi_leavebalance.*, supervisor_id FROM vi_leavebalance, employee WHERE employee.employee_id = vi_leavebalance.employee_id AND employee.supervisor_id = '".$_SESSION['empid']."' 
			ORDER BY vi_leavebalance.employee_id ASC, leavetype_id DESC";
		}
	}
	else{
		//check if user entered date range and click search button
		if (isset($_POST['search']))
		{
			$leavetypeid = $_POST['leavetypeid'];
			$query = "SELECT vi_leavebalance.*, supervisor_id FROM vi_leavebalance, employee WHERE employee.employee_id = vi_leavebalance.employee_id AND leavetype_id = '$leavetypeid' ORDER BY vi_leavebalance.employee_id ASC, leavetype_id DESC";
		}
		else if (isset($_POST['showall']))
		{
		
			$query = "SELECT vi_leavebalance.*, supervisor_id FROM vi_leavebalance, employee WHERE employee.employee_id = vi_leavebalance.employee_id ORDER BY vi_leavebalance.employee_id ASC, leavetype_id DESC";
		}
		else
		{
			$query = "SELECT vi_leavebalance.*, supervisor_id FROM vi_leavebalance, employee WHERE employee.employee_id = vi_leavebalance.employee_id ORDER BY vi_leavebalance.employee_id ASC, leavetype_id DESC";
		}
		
		
		
	}
		
		$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
	//$row = mysqli_fetch_assoc($result);
?>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	
	<div class = "maincontent">
		<h2>Leave Balance</h2>
		<form method = "post"><table>
		<tr><td>Select Leave Type: <select size="1" name="leavetypeid">
			<?php 
				$leavetype = mysqli_query($connection, "SELECT * from leavetype") or die(mysqli_error($connection));
				while ($line = mysqli_fetch_array($leavetype, MYSQLI_ASSOC)) 
				{ 
					echo "<option value='" . $line['leavetype_id'] . "'>"; 
					echo $line['leavetype_name'] . "</option>"; 
				} 
			?>
		</td><td><input type="submit" name="search" value="Run Query" style="hover: pointer;"></td><td><input type="submit" name="showall" value="Report All" style="hover: pointer;"></td></tr></table>
		<table class = "table" id="tblform">
			<tr>
				<td><a><b>Employee ID</b></b></td>
				<td><a><b>Employee Name</b></b></td>
				<td style="display: none;"><a><b>Leave Type ID</b></a></td>
				<td><a><b>Leave Type</b></a></td>
				<td><a><b>Maximum</b></a></td>
				<td><a><b>Earned Days</b></a></td>
				<td><a><b>Days Taken</b></a></td>
				<td><a><b>Leave Balance</b></a></td>
			</tr>
			<?php
				$i = 0;
				$mess = "No record found!";				
				if($result->num_rows > 0){
					while ($line=mysqli_fetch_assoc($result)){
						echo "<tr><center>";
						echo "<td>".$line['employee_id']."</td>";
						echo "<td>".$line['employeename']."</td>";
						echo "<td style='display: none;'>".$line['leavetype_id']."</td>";
						echo "<td>".$line['leavetype_name']."</td>";
						echo "<td>".$line['full_entitlement']."</td>";
						echo "<td>".$line['GrossEntitlement']."</td>";
						echo "<td>".$line['LeaveTaken']."</td>";
						echo "<td>".$line['LeaveBalance']."</td>";
						echo "</center></tr>";
						$i++;	
					}
				}
				else
				{					
					echo "<tr><td>". $mess . "</td></tr>";
				}	
				//db_connection_close();	
			?>
			</tbody>
			</table>
	</div>
	
	<!--<script src="src/js/main.js"></script>-->
	<?php db_connection_close();?>
	</body>
</html>

