<?php  
	
	session_start();
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	
	session();
	
	checkinactivity();

?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
		        
	</head>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	</div>
	<body>
		<?php 
			include_once($_SESSION['navifile']);
		?>
		<div class = "maincontent">		
		<?php	
			// Assigning POST values to variables.
			$firstname = escapeq(clean_it($_POST['firstname']));
			$lastname = escapeq(clean_it($_POST['lastname']));
			$genderid = $_POST['genderid'];
			$dob = clean_it($_POST['dob']);
			$datehired = clean_it($_POST['datehired']);
			$contactno = escapeq(clean_it($_POST['contactnumber']));
			$email = escapeq(clean_it($_POST['email']));
			$postid = $_POST['postid'];
			$departmentid = $_POST['departmentid'];
			$accessrightid = $_POST['accessrightid'];
			$username = escapeq(clean_it($_POST['username']));
			$password = escapeq(clean_it($_POST['passwd']));
			// Insert query
			$supervisorid = "";
			if ($departmentid != 4){  //CHECK IF division is not iverall management 
				
				$query1 = "SELECT employee_id FROM employee WHERE department_id = '$departmentid' AND post_id = 10"; 
				$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
				$row1 = mysqli_fetch_assoc($result1);
				$count = mysqli_num_rows($result1);
				if ($count == 1){
					$supervisorid = $row1['employee_id'];
				}
				else{
					$query1 = "SELECT employee_id FROM employee WHERE post_id = 8"; 
					$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
					$row1 = mysqli_fetch_assoc($result1);
					$supervisorid = $row1['employee_id'];
				}
			}
			else{
				
				$query1 = "SELECT employee_id FROM employee WHERE post_id = 8"; 
				$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
				$row1 = mysqli_fetch_assoc($result1);
				$supervisorid = $row1['employee_id'];
			}
			
			
			$query = "INSERT INTO employee (username, userpassword, first_name, last_name, gender_id, dob, date_hired, contact_number, email, accessright_id, supervisor_id, post_id, department_id) 
			VALUES('$username', PASSWORD('$password'), '$firstname', '$lastname','$genderid', '$dob', '$datehired', '$contactno', '$email', '$accessrightid', '$supervisorid', '$postid', '$departmentid')"; 
	
			$added = mysqli_query($connection, $query) or die(mysqli_error($connection));
		
			// report results
			if(!$added)
			{
				echo mysqli_error($connection);
			}
			else
			{
				echo "<center><b>"."Employee added successfully." . "</center></b><br>"; 
				//mail($email, $mailsubject, $mailbody); 
				//echo "<script type= 'text/javascript'>alert('Your application has been sent to your supervisor');</script>";
			}
			db_connection_close();	
		?>
		</div>
	</body>
</html>


