<?php  
	
	session_start();
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	
	session();

	checkinactivity();
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
		        
	</head>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
	</div>
	<body>
		<?php 
			include_once($_SESSION['navifile']);
		?>
		<div class = "maincontent">		
		<?php	
			// Assigning POST values to variables.
			$password=escapeq(clean_it($_POST['password']));
			$empnum= $_POST['empnum'];
			// build query using salt to password 
			$qry = "UPDATE employee SET userpassword=PASSWORD('$password') WHERE employee_id='$empnum'"; 
			
			$updated = mysqli_query($connection, $qry) or die(mysqli_error($connection));
			
			// report results
			if(!$updated)
			{
				echo mysqli_error($connection);
			}
			else
			{
				echo "<center><b>"."Password Updated successfully.". "</center></b><br>"; 
				//mail($email, $mailsubject, $mailbody); 
				
			}
		?>
		</div>
	</body>
</html>


