<!DOCTYPE html>
<?php
	require_once("../includes/db_connection.php");
	//session_name("user_time");
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	//check inactivity if exceed 5 minutes, auto end session and log out
	checkinactivity();
     	 
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		 <link rel="stylesheet" href="src/css/templatemo-style.css">
		<title>Supermarket 6</title>
	</head>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	<div class = "main" style="margin-left: 160px;" >
		<h2 style="margin-top:30px; color: black; margin-left:50px;">Welcome <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?> to the On-line Leave Management System</h2>

					</br>
						<div id="img" style="box-sizing: border-box; overflow: hidden;box-shadow: 5px 5px 10px grey;  margin-left:50px; width: 900px;">
						<img class="mySlides" src = "images/1.png" height=300 width=1000 style="object-fit: cover;" >
						 <img class="mySlides" src = "images/6.jpg" height=300 width=1000 style="object-fit: cover;" >
						 <img class="mySlides" src = "images/7.jpg " height=300 width=1000 style="object-fit: cover;" >
						  <img class="mySlides" src = "images/5.jpg " height=300 width=1000 style="object-fit: cover;" >
						 <img class="mySlides" src = "images/1.jpg" height=300 width=1000 style="object-fit: cover;" >
						</div>
						<script type="text/javascript" src="src/js/image_slide.js"></script>

		<p style="color: black; margin-top:50px;  margin-left:50px;">This site helps employees to apply for any type of leave from the comfort of your home or anywhere outside your work space. It is a web enable database that helps limit the use of paper and contribute to time management. Employees are required to fill in their required details along with the start and end date of your leave and select an option from the leave types available. 
		<p style="color:black;  margin-left:50px;">If you are an employee without a managerial title, your leave application will be approved by your Head of Department and if you are a manager applying for leave, your leave application will only be approved by the General Manager.
		It is important for employees to be aware and ensure all details entered are accurate and complete.	Employees can also check their status of their application online. Failure to follow instructions can lead to an invalid application.</p>		
	</div>
</body>
<script>
var box  = document.getElementById('box');
var down = false;


function toggleNotifi(){
	if (down) {
		box.style.height  = '';
		box.style.opacity = 0;
		down = false;
	}else {
		box.style.height  = ' 200%;';
		box.style.opacity = 1;
		down = true;
	}
}
</script>	
</html>
