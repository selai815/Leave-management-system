<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	//echo $_SESSION['empid'];
	checkinactivity();
	$empnum = $_SESSION['empid'];
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
		
	</head>
<?php 
		
	//connect to your mysql database 
	require_once("../includes/db_connection.php");
	
	
	//retrieve post_id for general manager
	$qry ="Select post_id from vi_employee WHERE employee_id='$empnum'";
	$res = mysqli_query($connection, $qry) or die(mysqli_error($connection));
	$row = mysqli_fetch_assoc($res);
	
	if ($row['post_id'] != 8){  //CHECK IF USER IS GENERAL MANAGER
		//check if user entered date range and click search button
		if (isset($_POST['search']))
		{
			if(!is_null($_POST['fromdate']) && !is_null($_POST['todate']))
			{
				$startdate=$_POST['fromdate'];
				$enddate=$_POST['todate'];
				$query = "SELECT * FROM vi_leaverequest WHERE approvingofficer_id ='".$_SESSION['empid']."' AND startdate Between '$startdate' AND '$enddate' and (decision_id =1) ORDER BY startdate DESC";
			}
		}
		else if (isset($_POST['showall']))
		{
			$query = "SELECT * FROM vi_leaverequest WHERE (decision_id =1) and approvingofficer_id ='".$_SESSION['empid']."' ORDER BY startdate DESC";
		}
		else
		{
			$query = "SELECT * FROM vi_leaverequest WHERE (decision_id =1) and approvingofficer_id ='".$_SESSION['empid']."' ORDER BY startdate DESC";
		}
	}
	else{
		if (isset($_POST['search']))
		{
			if(!is_null($_POST['fromdate']) && !is_null($_POST['todate']))
			{
				$startdate=$_POST['fromdate'];
				$enddate=$_POST['todate'];
				$query = "SELECT * FROM vi_leaverequest WHERE (decision_id =1) and startdate Between '$startdate' AND '$enddate' ORDER BY startdate DESC";
			}
		}
		else if (isset($_POST['showall']))
		{
			$query = "SELECT * FROM vi_leaverequest  where (decision_id =1) ORDER BY startdate DESC";
		}
		else
		{
			$query = "SELECT * FROM vi_leaverequest where (decision_id =1) ORDER BY startdate DESC";
		}
	}
	
	$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
?>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	
	<div class = "maincontent">
		<h2>Employees Leave History</h2>
		<form method = "post"><table>
		<tr><td>From Date: <input type="date" name="fromdate"></td><td>To Date: <input type="date" name="todate"></td><td><input type="submit" name="search" value="Run Query" style="hover: pointer;"></td><td><input type="submit" name="showall" value="Report All" style="hover: pointer;"></td></tr></table></form>
		<table class = "table" id="tblform">
			<thead>
				<tr>
					<td><a><b>Leave ID</b></b></td>
					<td><a><b>Employee</b></b></td>
					<td><a><b>Leave Type</b></a></td>
					<td><a><b>Start Date</b></a></td>
					<td><a><b>End Date</b></a></td>
					<td><a><b>Total Days</b></a></td>
					<td><a><b>Date Applied</b></a></td>
					<td><a><b>Status</b></td></a></tr>							
				</tr>			
			</thead>
			<tbody>
			<?php
				$i = 0;
				$mess = "No Records Found";
				
				if($result->num_rows > 0){
					while ($line=mysqli_fetch_assoc($result)){
						echo "<tr><td><center>";
						echo "<a href =leavedetails.php?requestnum=" .$line['leaverequest_id'].">".$line['leaverequest_id']."</a></center></td>";
						echo "<td>".$line['employeename']."</td>";
						echo "<td>".$line['leavetype_name']."</td>";
						echo "<td>".date("d-m-Y", strtotime($line['startdate']))."</td>";
						echo "<td>".date("d-m-Y", strtotime($line['enddate']))."</td>";
						echo "<td>".$line['totaldays']."</td>";
						echo "<td>".date("d-m-Y", strtotime($line['application_date']))."</td>";
						echo "<td>".$line['decision_name']."</td>";
						echo "</tr>";
						$i++;	
					}
				}
				else
				{					
					echo "<tr><td>". $mess . "</td></tr>";
				}	
				//db_connection_close();	
			?>
			</tbody>
			</table>
	</div>
	
	<!--<script src="src/js/main.js"></script>-->
	<?php db_connection_close();?>
	</body>
</html>

