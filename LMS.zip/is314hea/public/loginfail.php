<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
   <title> Supermarket 6 </title>
    <link rel="stylesheet" href="src/css/login.css">
</head>
<body  background="images/s.jpg" style="background-size:200%; background-repeat: no-repeat;">

<div id="line">
	    <div id="heading" style="margin-bottom: 70px;">
	      <h1>SUPERMARKET 6 LEAVE MANAGEMENT SYSTEM</h1>
	    </div>
<div class="testbox">
  <h1  style="color:grey;">Invalid Credentials</h1><form id="loginform" method="post" action="loginverify.php" >
  
   <hr> 
   <br>
  <input type="text" name="username" id="username" placeholder="Username" required style="font-size: 14px; height: 20px; width:50%; margin-right: 20px;"/>
  <br>
  <br>
  <input type="password" name="password" id="password" placeholder="Password" required style="font-size: 14px; height: 20px; width:50%; margin-right: 20px;"/>
  <div>
   <div style=" width: 35%; margin-top: 20px; margin-left: 160px; padding-top: 0px;">
  	<input type="submit" class="sub_button" id="name" value="LOGIN" style=" background-color:#3498db;  text-align: center; font-size: 14px; border-radius: 12px; padding: 1px; width: 45%; color:white" name="submit"> &nbsp;
	<input type="reset" value="CLEAR"  style=" background-color:#3498db; text-align: center; font-size: 14px; border-radius: 12px;  padding: 1px; width: 45%; color: white; "  />
  </div>
  <div style="width: 50%;  float:left;  margin-left: 130px; padding-top: 5px;">
  <p>Forgot your password? <a href="#">Contact Administrator</a>
  </div>
  </div>
  </form>
</div>
    

</body>
</html>