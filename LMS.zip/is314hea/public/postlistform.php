<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	
	checkinactivity();
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
	</head>
<?php 
	// include the file that defines (contains) the username and password
	require_once("../includes/db_connection.php");
	//connect to your mysql database
	
	//retrieve employee record
	
	$query = "SELECT * FROM post ORDER BY salary_level";
	$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
	//recordset retrieved
	
	
?>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	<div class = "maincontent">
		<h2>Position List</h2>
		<form action="postaddform.php"><input type="submit" style="margin-top: 10px; height: 30px; font-size: 14px; hover: pointer;" value="ADD POST" /></form>
		
		<table class = "table" id="tblform">
			<thead>
				<tr><td><a><b>Post ID.</b></b></td>
					<td><a><b>Post Name</b></a></td>
					<td><a><b>Post Description</b></a></td>
					<td><a><b>Salary Level</b></a></td>
				</tr>			
			</thead>
			<tbody>
			<?php
				$i = 0;
				$mess = "No leave record";
				if($result->num_rows > 0){
					while ($line=mysqli_fetch_assoc($result)){
						echo "<tr><td><center>";
						echo "<a href =postupdateform.php?postnum=" .$line['post_id'].">".$line['post_id']."</a></center></td>";
						echo "<td>".$line['post_name']. "</td>";
						echo "<td>".$line['post_desc']."</td>";
						echo "<td>".$line['salary_level']."</td>";
						echo "</tr>";
						$i++;	
					}
				}
				else
				{					
					echo "<tr><td>". $mess . "</td></tr>";
				}	
			?>
				
			</tbody>
		</table>
	</div>
	
	<!--<script src="src/js/main.js"></script>-->
	<?php db_connection_close();?>
	</body>
</html>

