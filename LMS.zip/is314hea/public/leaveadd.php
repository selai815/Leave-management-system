<?php  
	
	session_start();
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	
	session();
	
	checkinactivity();

?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
		        
	</head>
		<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	</div>
	<body>
		<?php 
			include_once($_SESSION['navifile']);
		?>
		<div class = "maincontent">		
		<?php	
			// Assigning POST values to variables.
			$leavetypeid=clean_it($_POST['leavetypeid']);
			$startdate = clean_it($_POST['startdate']);
			$enddate = clean_it($_POST['enddate']);
			$totaldays = clean_it($_POST['totaldays']);
			$remarks = escapeq(clean_it($_POST['remarks']));
			$applicationdate = clean_it($_POST['applicationdate']);
			$approvingoffcerid = clean_it($_POST['approvingofficerid']);
			$empid=$_SESSION['empid'];
			$email=clean_it($_POST['email']);
			$employeename=$_SESSION['fname']." ". $_SESSION['lname'];
			$mailsubject="Leave Application From ";
			$mailbody="There is an application for leave from ". $employeename. " submitted for your approval";
			$curyear = date('Y');
			
			if (date("Y", strtotime($startdate)) < $curyear){
				function_alert("Invalid Year!!!");
				echo "<center><b>"."An expired calendar year, try again."."</center></b><br>"; 
					exit;
			}
				
			if ($totaldays < 1){
					function_alert("Invalid Dates!!!");
					echo "<center><b>"."Start date must be before end date, try again."."</center></b><br>"; 
					exit;
			}
			
			$qry= "SELECT * FROM vi_leavebalance WHERE employee_id='$empid' AND leavetype_id='$leavetypeid'";
			$result = mysqli_query($connection, $qry) or die(mysqli_error($connection));
			$row = mysqli_fetch_assoc($result);
			
			if ($totaldays > $row['LeaveBalance'] ){
				function_alert("Exceeds Balance!!!");
				echo "<center><b>"."Requested days exceed leave entitlement, try again."."</center></b><br>"; 
					exit;
			}
			
			// Insert query
			$query = "INSERT INTO leaverequest (employee_id, leavetype_id, application_date, startdate, enddate, totaldays, justification, approvingofficer_id) VALUES('$empid', '$leavetypeid', STR_TO_DATE('$applicationdate','%d-%m-%Y'), STR_TO_DATE('$startdate','%d-%m-%Y'), STR_TO_DATE('$enddate','%d-%m-%Y'), '$totaldays', '$remarks','$approvingoffcerid')";
			$added = mysqli_query($connection, $query) or die(mysqli_error($connection));
		
			// report results
			if(!$added)
			{
				echo mysqli_error($connection);
			}
			else
			{
				echo "<center><b>"."Leave application submitted successfully" . "</center></b><br>"; 
				//mail($email, $mailsubject, $mailbody); 
				echo "<script type= 'text/javascript'>alert('Your application has been sent to your supervisor');</script>";
			}
			db_connection_close();
		?>
				<table><tr><td></td></tr>
			<center><form action="leaveapplyform.php"><input type="submit" style="font-size: 22px;" value="BACK"/></form></center></table>
	
		</div>
	</body>
</html>


