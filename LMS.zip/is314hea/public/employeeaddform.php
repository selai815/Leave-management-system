<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	require_once("../includes/db_connection.php");
	session();
	
	checkinactivity();

?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
	</head>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	<form id="employeeaddform" method="post" action="employeeadd.php">
	
	<div class = "maincontent">
		<h2>Add New Employee</h2>
		<table id="tblprofile">
			<tr><td style="width:200px;"><a><b>First Name</b></a></td><td><input type="text"  name="firstname" placeholder="First Name" style="width:100%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required/></td></tr>
			<tr><td style="width:200px;"><a><b>Last Name</b></a></td><td><input type="text" name="lastname" placeholder="Last Name" style="width:100%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required /></td></tr>
			<tr><td style="width:200px;"><a><b>Gender</b></a></td><td><select size="1" name="genderid" placeholder="Select Gender" style="width: 200px; font-size: 16px; border: none; background-color: #a3ffce;" required >
			<?php 
				$qrygender = mysqli_query($connection, "SELECT * from gender") or die(mysqli_error($connection));
				echo '<option value=""></option>';
				while ($line = mysqli_fetch_array($qrygender, MYSQLI_ASSOC)) 
				{ 
					echo "<option value='" . $line['gender_id'] . "'>"; 
					echo $line['gender_name'] . "</option>"; 
				} 
				echo '</select>';
			?></td></tr>
			<tr><td style="width:200px;"><a><b>D.O.B</b></a></td><td><input type="date" class="textbox" id="dob" name="dob" style="width:40%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required/></td></tr>
			<tr><td style="width:200px;"><a><b>Date Hired</b></a></td><td><input type="date" class="textbox" id="datehired" name="datehired" style="width:40%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required/></td></tr>
			<tr><td style="width:200px;"><a><b>Contact Number</b></a></td><td><input type="text"  name="contactnumber" placeholder="Contact Number" style="width:100%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required/></td></tr>
			<tr><td style="width:200px;"><a><b>Email</b></a></td><td><input type="text" placeholder="E-mail"  name="email" style="width:100%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required/></td></tr>
			<tr><td style="width:200px;"><a><b>Post</b></td></a><td><select size="1" name="postid" style="width: 300px; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required>
			<?php 
				$qrypost = mysqli_query($connection, "SELECT * from post") or die(mysqli_error($connection));
				echo '<option value=""></option>';
				while ($line = mysqli_fetch_array($qrypost, MYSQLI_ASSOC)) 
				{ 
					echo "<option value='" . $line['post_id'] . "'>"; 
					echo $line['post_name'] . "</option>"; 
				} 
				echo "</select>"; 
			?></td></tr>
			<tr><td style="width:200px;"><a><b>Department</b></td></a><td><select size="1" name="departmentid" style="width: 300px; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required>
			<?php 
				// fill department drop box with department names
				$qrydepartment = mysqli_query($connection, "SELECT * from department") or die(mysqli_error($connection));
				echo '<option value=""></option>';
				while ($line = mysqli_fetch_array($qrydepartment, MYSQLI_ASSOC)) 
					{ 
						echo "<option value='" . $line['department_id'] . "'>"; 
						echo $line['department_name'] . "</option>"; 
					} 
					echo "</select>"; 
			?></td></tr>
			<tr><td style="width:200px;"><a><b>Accessright</b></td></a><td><select size="1" name="accessrightid" style="width: 300px; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required>
			<?php 
				// fill department drop box with department names
				$qryaccess = mysqli_query($connection, "SELECT * from accessright") or die(mysqli_error($connection));
				echo '<option value=""></option>';
				while ($line = mysqli_fetch_array($qryaccess, MYSQLI_ASSOC)) 
					{ 
						echo "<option value='" . $line['accessright_id'] . "'>"; 
						echo $line['accessright_name'] . "</option>"; 
					} 
					echo "</select>"; 
			?></td></tr>
			<tr><td style="width:200px;"><a><b>Username</b></a></td><td><input type="text"  name="username" placeholder="Username" style="width:100%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required/></td></tr>
			<tr><td style="width:200px;"><a><b>User Password</b></a></td><td><input type="text"  name="passwd" minlength="8" placeholder="Password must be 8 Characters or more"style="width:100%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required/></td></tr>
			<tr><td style="width:200px;" colspan="2"><a><b></b></a></td></tr>
			<tr><td colspan = "2" style="width: 200px;"><input type="submit" value="Add Employee" name="submit" style="margin-left: 120px; background-color:#008080; text-align: center; font-size: 14px; border-radius: 12px; padding: 2px; width: 15%; color: white; cursor: pointer;"/>
			<input type="reset" value="CLEAR" name="clear" style="margin-left: 100px; background-color:#008080; text-align: center; font-size: 14px; border-radius: 12px;  padding: 2px; width: 15%; color: white; cursor: pointer;" />
			
		</table>
	</div>
	<!--<script src="src/js/main.js"></script>-->
</body>
</html>
