<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	//echo $_SESSION['empid'];
	checkinactivity();
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
	</head>

 <div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	<div class = "maincontent">
		<h2>Leave Reports and Queries</h2>
	
		<table class = "table" id="tblform">
			<tr><td style="width:400px;"><a><b>All Employees Leave</b></a></td><td><form action="reportallleave.php"><input type="submit" value=" Open Report" /></form></td></tr>
			<tr><td style="width:200px;"><a><b>All Employees Leave By Leave Type</b></a></td><td><form action="reportleavetype.php"><input type="submit" value=" Open Report" /></form></td></tr>
			<tr><td style="width:200px;"><a><b>Leave By Specific Employee</b></a></td><td><form action="reportbyemplist.php"><input type="submit" value=" Open Report" /></form></td></tr>
			<tr><td style="width:200px;"><a><b>Leave Balance By Employee</b></td></a><td><form action="reportleavebalance.php"><input type="submit" value=" Open Report" /></td></tr>
		</table>
	</div>
	
	<!--<script src="src/js/main.js"></script>-->
	<?php db_connection_close();?>
	</body>
</html>

