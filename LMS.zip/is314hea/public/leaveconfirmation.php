<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	//echo $_SESSION['empid'];
	checkinactivity();
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
		        
	</head>
<?php 
	$leavetypeid=$_GET['leavetype'];
	$startdate=$_GET['startdate'];
	$enddate=$_GET['enddate'];
	$remarks=$_GET['remarks'];
	$totaldays=$_GET['totaldays'];
	$approvingofficerid=$_GET['supervisorid'];	
	// include the file that defines (contains) the username and password
	require_once("../includes/db_connection.php");
	
	$query1 = "SELECT * FROM vi_employee WHERE employee_id ='".$_SESSION['empid']."'";
	$query2 = "SELECT employee_id, leavebalance, leavetype_name FROM vi_leavebalance WHERE leavetype_id = $leavetypeid AND employee_id ='".$_SESSION['empid']."'";
	
	$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
	$result2 = mysqli_query($connection, $query2) or die(mysqli_error($connection));
	
	$rowq1 = mysqli_fetch_assoc($result1);
	$rowq2 = mysqli_fetch_assoc($result2);
		
?>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	<form id="leaveapplication" method="post" action="leaveadd.php">
	<div class = "maincontent">
		<h2>Confirm Application</h2>
		<table style="border: 1px;">
			<tr><td style="width:200px;"><a><b>Employee ID</b></a></td><td><?php echo $rowq1['employee_id']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Name</b></a></td><td><?php echo $rowq1['first_name']." ". $rowq1['last_name']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Post</b></a></td><td><?php echo $rowq1['post_name']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Department</b></td></a><td><?php echo $rowq1['department_name']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Leave Type</b></a></td><td><input type="text" id="leavetype" name="leavetype" style="width:40%; font-size: 16px; border: none; height:20%; color: #990000;" value="<?php echo $rowq2['leavetype_name'];?>" readonly></td></tr>
			<tr><td style="width:200px;"><a><b>From Date</b></td></a><td><input type="text" id="begin" name="startdate" style="width:40%; font-size: 16px; border: none; height:20%; color: #990000;" value="<?php echo date("d-m-Y", strtotime($startdate));?>" readonly></td></tr>
			<tr><td style="width:200px;"><a><b>To Date</b></td></a><td><input type="text" id="end" name="enddate" style="width:40%; font-size: 16px; border: none; height:20%; color: #990000;" value="<?php echo date("d-m-Y", strtotime($enddate));?>" readonly></td></tr>
			<tr><td style="width:200px;"><a><b>Total Days</b></a></td><td><input type="text" id="total" name="totaldays" style="width:40%; font-size: 16px; border: none; height:20%; color: #990000;" value="<?php echo $totaldays;?>" readonly></td></tr>
			<tr><td style="width:200px; margin-top: -10px;"><a><b>Remarks</b></a></td><td><textarea rows="3" cols="70" type="text" id="remarks" name="remarks" style="width:40%; font-size: 16px; border: none; height:20%; color: #990000;" readonly><?php echo $remarks;?></textarea></td></tr>
			<tr><td style="width:200px;"><a><b>To Be Approved By</b></td></a><td><?php echo $rowq1['ReportsTo']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Application Date</b></a></td><td><input type="text" id="appdate" name="applicationdate" style="width:40%; font-size: 16px; border: none; height:20%; color: #990000;" value="<?php echo date("d-m-Y");?>" readonly></td></tr>
			<tr><td><input type="hidden" id="leavetypeid" name="leavetypeid" value="<?php echo $leavetypeid;?>"></td><td><input type="hidden" id="approvingid" name="approvingofficerid" value="<?php echo $approvingofficerid;?>"></td></tr>
			<tr><td><input type="hidden" id="email" name="email" value="<?php echo $rowq1['email'];?>"></td><td><input type="hidden" id="vacant" name="vacant" value="<?php echo "Vacant SLot";?>"></td></tr>
			<tr><td colspan = "2" rows="6" align="center" width="100%" height="20" background="#000090"></td></tr>
			<tr><td colspan = "2" style="width: 200px;"><input type="submit" value="CONFIRM" name="submit" style="margin-left: 120px; background-color:#008080; text-align: center; font-size: 14px; border-radius: 12px;  padding: 2px; width: 15%; color: white; cursor: pointer;"/>
			<input type="BACK" value="BACK" name="Back" style="margin-left: 100px; background-color:#008080; text-align: center; font-size: 14px; border-radius: 12px;  padding: 2px; width: 15%; color: white; cursor: pointer;"  onclick="history.back()"/>
			</td></tr>
			
			<tr><td></td><td></td></tr>
		</table>		
	</div>
	<!--<script src="src/js/main.js"></script>-->
</body>
</html>
