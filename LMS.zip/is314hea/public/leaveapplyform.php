<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	
	checkinactivity();

	$empid=$_SESSION['empid'];
	
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
	</head>
	
<?php 
		
	// include the file that defines (contains) the username and password
	require_once("../includes/db_connection.php");
	//connect to your mysql database
		
	//retrieve employee record
	$query = "SELECT * FROM vi_employee WHERE employee_id ='$empid'";
	$query2 = "SELECT employee_id,employeename,
				SUM(IF(leavetype_id=1, LeaveBalance, NULL)) AS Casual,
				SUM(IF(leavetype_id=2, LeaveBalance, NULL)) AS Bereavement,
				SUM(IF(leavetype_id=3, LeaveBalance, NULL)) AS Sick,
				SUM(IF(leavetype_id=4, LeaveBalance, NULL)) AS Maternity,
				SUM(IF(leavetype_id=5, LeaveBalance, NULL)) AS Vacation
				FROM vi_leavebalance WHERE employee_id ='$empid'";
	
	$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
	$result2 = mysqli_query($connection, $query2) or die(mysqli_error($connection));
	//recordset retrieved
	$row = mysqli_fetch_assoc($result);
	$rowq2 = mysqli_fetch_assoc($result2);
?>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	<form id="leaveapplyform" method="get" action="leaveconfirmation.php">
	<div class = "maincontent">
		<h2>Leave Application</h2>
		<table id="tblprofile">
			<tr><td style="width:200px;"><a><b>Employee ID</b></a></td><td><?php echo $row['employee_id']; ?></td><td><b><a>Leave Balance</b></a></td></tr>
			<tr><td style="width:200px;"><a><b>Name</b></a></td><td><?php echo $row['first_name']." ". $row['last_name']; ?></td><td>Casual: <?php echo $rowq2['Casual']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Post</b></a></td><td><?php echo $row['post_name']; ?></td><td>Bereavement: <?php echo $rowq2['Bereavement']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Department</b></td></a><td><?php echo $row['department_name']; ?></td><td>Sick: <?php echo $rowq2['Sick']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Leave Type</b></a></td><td><select size="1" name="leavetype" style="width: 200px; font-size: 16px; border: none; background-color: #a3ffce;">
			<?php 
				$leavetype = mysqli_query($connection, "SELECT * from leavetype") or die(mysqli_error($connection));
				while ($line = mysqli_fetch_array($leavetype, MYSQLI_ASSOC)) 
				{ 
					echo "<option value='" . $line['leavetype_id'] . "'>"; 
					echo $line['leavetype_name'] . "</option>"; 
				} 
			?></td><td>Maternity: <?php echo $rowq2['Maternity']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>From Date</b></td></a><td><input type="date" class="textbox" id="fromdate" name="startdate" style="width:40%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" onchange="cal()"></td><td>Vacation: <?php echo $rowq2['Vacation']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>To Date</b></td></a><td><input type="date" class="textbox" id="todate" name="enddate" style="width:40%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" onchange="cal()"/></td></tr>
			<tr><td style="width:200px;"><a><b>Total Days</b></a></td><td><input type="text" class="textbox" id="totaldays" name="totaldays" style="width:40%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" readonly /></td>
			<tr><td style="width:200px; row: 2;"><a><b>Remarks</b></a></td><td colspan="2"><textarea style="background-color: #a3ffce; font-size: 16px; border: none;" type="text" id="remarks" name="remarks" rows="4" cols="50"></textarea></td></tr>
			<tr><td style="width:200px;"><a><b>To Be Approved By</b></td></a><td colspan="2"><?php echo $row['ReportsTo']; ?></td></tr>
			<tr><td><input type="hidden" colspan = "3" rows="2" name="supervisorid" align="center" width="100%" height="20" colspan="3" value=<?php echo $row['supervisor_id']; ?> ></td></tr>
			<tr><td colspan = "3" style="width: 200px;"><input type="submit" value="SUBMIT" name="submit" style="margin-left: 120px; background-color:#008080; text-align: center; font-size: 14px; border-radius: 12px; padding: 2px; width: 15%; color: white; cursor: pointer;"/>
			<input type="reset" value="CLEAR" name="clear" style="margin-left: 100px; background-color:#008080; text-align: center; font-size: 14px; border-radius: 12px;  padding: 2px; width: 15%; color: white; cursor: pointer;" />
			</td></tr>
		</table>
	</div>
	</form>
	<script src="src/js/main.js"></script>
	<?php db_connection_close();?>
	</body>
</html>
