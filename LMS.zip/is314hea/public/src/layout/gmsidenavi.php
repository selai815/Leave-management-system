<div id="mySidenav" class="sidenav" style="height:110%;">
			<a style="weight: Bold; color: #D4af37;">GENERAL MANAGER</a>
			</br>
			<a href="profile.php" style="margin-right:110px;">Profile</a>
			<a href="leavehistory.php"style="margin-right:55px;">Leave History</a>
			<a href="leaveforapproval.php">Leave For Approval</a>
			<a href="reportmainpage.php" style="margin-right:58px;">Leave Report</a>
			<a href="logingout.php"style="margin-right:90px;" >Log Out</a>
</div>