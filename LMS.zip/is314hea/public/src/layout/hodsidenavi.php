<div id="mySidenav" class="sidenav"style="height:110%;" >
			<a style="weight: Bold; color: #D4af37;">HEAD OF DIVISION</a>
			</br>
			<a href="profile.php" style="margin-right:110px;">Profile</a>
			<a href="leaveapplyform.php" style="margin-right:40px;" >Apply For Leave</a>
			<a href="leavehistory.php"style="margin-right:55px;">Leave History</a>
			<a href="leaveforapproval.php">Leave For Approval</a>
			<a href="reportmainpage.php" style="margin-right:60px;">Leave Report</a>
			<a href="logingout.php"style="margin-right:90px;" >Log Out</a>
</div>