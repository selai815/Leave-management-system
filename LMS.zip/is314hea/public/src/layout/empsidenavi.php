<div id="mySidenav" class="sidenav" style="height:110%;">
			<a style="weight: Bold; color: #D4af37; margin-right:70px; ">EMPLOYEE</a>
			<br>
			<a href="profile.php" style="margin-right:100px;"  >Profile</a>
			<a href="leaveapplyform.php" style="margin-right:29px;">Apply For Leave</a>
			<a href="leavehistory.php"style="margin-right:48px;" >Leave History</a>
			<a href="logingout.php" style="margin-right:90px;" >Log Out</a>
</div>