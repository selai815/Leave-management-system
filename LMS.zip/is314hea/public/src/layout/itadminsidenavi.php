<div id="mySidenav" class="sidenav">
			<a style="weight: Bold; color: #D4af37;">IT ADMINISTRATOR</a>
			<a href="profile.php">Profile</a>
			<a href="leaveapplyform.php">Apply For Leave</a>
			<a href="leavehistory.php">Leave History</a>
			<a href="#">Approve Leave</a>
			<a href="#">Leave Report</a>
			<a href="#">Add/Edit Employee</a>
			<a href="#">Add/Edit Post</a>
			<a href="#">Add/Edit Department</a>
			<a href="#">Add/Edit Leave Type</a>
			<a href="#">Add/Edit Access Right</a>
			<a href="passwordmineresetform.php">Reset My Password</a>		
			<a href="logingout.php">Log Out</a>
</div>