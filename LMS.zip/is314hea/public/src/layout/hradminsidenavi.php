<div id="mySidenav" class="sidenav"style="height:205%;" >
			<a style="weight: Bold; color: #D4af37;">HR ADMINISTRATOR</a>
			</br>
			<a href="profile.php" style="margin-right:110px;">Profile</a>
			<a href="leavehistory.php"style="margin-right:55px;">Leave History</a>
			<a href="leaveapplyform.php" style="margin-right:40px;">Apply For Leave</a>
			<a href="leavehistory.php" style="margin-right:56px;">Leave History</a>
			<a href="employeelistform.php" style="margin-right:20px;">Add/Edit Employee</a>
			<a href="postlistform.php"style="margin-right:63px;" >Add/Edit Post</a>
			<a href="deptlistform.php"style="margin-left;1px;">Add/Edit Department</a>
			<a href="leavetypelistform.php"style="margin-right:47px;">Edit Leave Type</a>
			<a href="userlistreport.php" style="margin-right:63px;">User's Report</a>
			<a href="logingout.php"style="margin-right:100px;">Log Out</a>
</div>