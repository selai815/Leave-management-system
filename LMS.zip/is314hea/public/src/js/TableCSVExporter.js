class TableCSVExporter {
	constructor (table, includeHeaders = true){
		this.table = table;
		this.rows=Array.from(table.querySelectorAll("tr"));
		
		console.log(this); 
	}
	convertToCSV(){
		const line = [];
		const numCols = this._findLongestRowLength();
			
		for (const row of this.rows) {
			let line = "";
			
			for (let i = 0; i < numCols; i++){
				if (row.children[i] !==undefined) {
					line += TableCSVExporter.parseCell(row.children[i]);
				} 
				
				line += (i !== (numCols - 1)) ? "," : "";
			}
			
			lines.push(line);
		}

	}
	_findLongestRowLength(){
		return this.rows.reduce((1, row) => row.childElementCount > 1 ? row.childElementCount : 1, 0); 		
	}
	static parsecell (tableCell){
		let parsedValue = tableCell.textContent;
		
		//replace double quotes with two double quotes
		parsedValue = parsedValue.replace(/"/g, '""');
		
		//if values contains comma, new line or double-quote, enclose in double quotes
		parsedValue = /[",\n]/.test(parsedValue) ? '"${parsedValue}"' : parsedValue;
		
		return parsedValue;
		
	} 
	
}
