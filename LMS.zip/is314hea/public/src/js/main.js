/* Set the width of the side navigation to 250px and the left margin of the page content to 220px */
function openNav() {
	document.getElementById("mySidenav").style.width = "180px";
	document.getElementById("myContent").style.marginLeft = "200px";
	document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
	hidetoggle();
}

function closeNav() {
	document.getElementById("mySidenav").style.width = "0";
	document.getElementById("myContent").style.marginLeft = "20px";
	document.body.style.backgroundColor = "white";
	showtoggle();
}

function showtoggle() {
	var x = document.getElementById("myToggle");
	x.style.display = "block";
}

function hidetoggle() {
	var x = document.getElementById("myToggle");
	x.style.display = "none";
}
function myFunction() {
	var x = document.getElementById("myDIV");
	if (x.style.display === "none") {
		x.style.display = "block";
	} else {
		x.style.display = "none";
	}
} 
function GetDays(){
    var dropdt = new Date(document.getElementById("fromdate").value);
    var pickdt = new Date(document.getElementById("todate").value);
    return parseInt((pickdt-dropdt) / (24 * 3600 * 1000) + 1);
}
		
function cal(){
	if(document.getElementById("todate")){
		document.getElementById("totaldays").value=GetDays();
	}  
}