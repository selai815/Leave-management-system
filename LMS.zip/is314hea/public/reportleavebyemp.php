<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	
	checkinactivity();
	
	$empid = $_GET['empnum'];
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
		
	</head>
<?php 
		
	// include the file that defines (contains) the username and password
	require_once("../includes/db_connection.php");
	//connect to your mysql database
	
	//Retrieve selected employee for name display
	$guery1 = "SELECT first_name, last_name FROM employee WHERE employee_id ='$empid'";
	$result1 = mysqli_query($connection, $guery1) or die(mysqli_error($connection));
	$row = mysqli_fetch_assoc($result1);
	
	//check if user entered date range and click search button
	if (isset($_POST['search']))
	{
		if(!is_null($_POST['fromdate']) && !is_null($_POST['todate']))
		{
			$startdate=$_POST['fromdate'];
			$enddate=$_POST['todate'];
			$query = "SELECT vi_leaverequest.*, employee.first_Name, employee.first_Name FROM vi_leaverequest, employee WHERE vi_leaverequest.employee_id ='$empid' AND startdate Between '$startdate' AND '$enddate' AND 
			employee.employee_id = vi_leaverequest.approvingofficer_id ORDER BY leavetype_id"; 
		}
	}
	elseif (isset($_POST['showall'])) 
	{
		$query = "SELECT vi_leaverequest.*, employee.first_Name, employee.first_Name FROM vi_leaverequest, employee WHERE vi_leaverequest.employee_id ='$empid' AND 
		employee.employee_id = vi_leaverequest.approvingofficer_id ORDER BY leavetype_id"; 
	}
	else
	{
		$query = "SELECT vi_leaverequest.*, employee.first_Name, employee.first_Name FROM vi_leaverequest, employee WHERE vi_leaverequest.employee_id ='$empid' AND 
		employee.employee_id = vi_leaverequest.approvingofficer_id ORDER BY leavetype_id"; 
	}	
	
	$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
?>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	
	<div class = "maincontent">
		<h2>Leave: <?php echo $row['first_name']. " ". $row['last_name'] ?></h2>
		<form method = "post"><table>
		</td><td>From Date: <input type="date" name="fromdate"></td><td>To Date: <input type="date" name="todate"></td><td><input type="submit" name="search" value="Run Query" style="hover: pointer;"></td><td><input type="submit" name="showall" value="Report All" style="hover: pointer;"></td></tr></table></form>
		<table class = "table" id="tblform">
			<thead>
				<tr>
					<td><a><b>Leave ID</b></b></td>
					<td style="display: none;"><a><b>Employee ID</b></a></td>
					<td><a><b>Leave Type</b></a></td>
					<td><a><b>Start Date</b></a></td>
					<td><a><b>End Date</b></a></td>
					<td width="20px;"><a><b>Total</b></a></td>
					<td><a><b>Date Applied</b></a></td>
					<td><a><b>Status</b></td></a></tr>							
				</tr>			
			</thead>
			<tbody>
			<?php
				$i = 0;
				$mess = "No Redords Found";
				
				if($result->num_rows > 0){
					while ($line=mysqli_fetch_assoc($result)){
						echo "<tr><td><center>";
						echo "<a href =leavedetails.php?requestnum=" .$line['leaverequest_id'].">".$line['leaverequest_id']."</a></center></td>";
						echo "<td style='display: none;'>".$line['employeename']."</td>";
						echo "<td>".$line['leavetype_name']."</td>";
						echo "<td>".date("d-m-Y", strtotime($line['startdate']))."</td>";
						echo "<td>".date("d-m-Y", strtotime($line['enddate']))."</td>";
						echo "<td>".$line['totaldays']."</td>";
						echo "<td>".date("d-m-Y", strtotime($line['application_date']))."</td>";
						echo "<td>".$line['decision_name']." (".date("d-m-Y", strtotime($line['decision_date'])).") "."</td>";
						echo "</tr>";
						$i++;	
					}
				}
				else
				{					
					echo "<tr><td>". $mess . "</td></tr>";
				}	
				//db_connection_close();	
			?>
			<tr><td colspan="3"></td></tr>
			<tr><td colspan="3"><form action="reportbyemplist.php"><input type="submit" value="BACK"/></form></td></tr>
			</tbody>
			</table>
	</div>
	
	<!--<script src="src/js/main.js"></script>-->
	<?php db_connection_close();?>
	</body>
</html>

