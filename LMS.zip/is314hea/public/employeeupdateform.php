<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	//echo $_SESSION['empid'];
	checkinactivity();
	
	$empnum=$_GET['empnum'];
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
	</head>
<?php 
		
	
	// include the file that defines (contains) the connection to the mysql database
	require_once("../includes/db_connection.php");
	//connect to your mysql database
	
	$query1 = "Select * from vi_employee WHERE employee_id='$empnum'";
		
	$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
	$rowq1 = mysqli_fetch_assoc($result1);
	
	
?>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	<form id="employeeupdateform" method="post" action="employeeupdate.php">
	
	<div class = "maincontent">
		<h2>Edit Employee</h2>
		<table id="tblprofile">
			<tr><td style="width:200px;"><a><b>Employee ID</b></a></td><td><input type="text" style="width:100%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" name="empnum" value="<?php echo $rowq1['employee_id'];?>" readonly></td></tr>
			<tr><td style="width:200px;"><a><b>First Name</b></a></td><td><input type="text" style="width:100%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" name="firstname" value="<?php echo $rowq1['first_name'];?>"> </td></tr>
			<tr><td style="width:200px;"><a><b>Last Name</b></a></td><td><input type="text" style="width:100%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" name="lastname" value="<?php echo $rowq1['last_name'];?>"></td></tr>
			<tr><td style="width:200px;"><a><b>Gender</b></a></td><td><select size="1" name="genderid" style="width: 200px; font-size: 16px; border: none; background-color: #a3ffce;">
			<?php 
			// fill gender list box with department names
			$qrygender = mysqli_query($connection, "SELECT * from gender") or die(mysqli_error($connection));
			while ($line = mysqli_fetch_array($qrygender, MYSQLI_ASSOC)) 
			{ 
				echo "<option value='" . $line['gender_id'] . "'";
				if($line['gender_id'] == $rowq1['gender_id'])
					echo " selected='selected' ";
			
				echo ">"; 
				echo $line['gender_name'] . "</option>"; 
			} 
			?></td>
			<tr><td style="width:200px;"><a><b>D.O.B</b></a></td><td><input type="date"  name="dob" style="font-size: 16px; border: none; background-color: #a3ffce; height:20%;" class="m-wrap" value="<?php echo strftime('%Y-%m-%d', strtotime($rowq1['dob'])); ?>" /></td></tr>
			<tr><td style="width:200px;"><a><b>Date Hired</b></a></td><td><input type="date"  name="datehired" style="font-size: 16px; border: none; background-color: #a3ffce; height:20%;" class="m-wrap" value="<?php echo strftime('%Y-%m-%d', strtotime($rowq1['date_hired'])); ?>" /></td></tr>
			<tr><td style="width:200px;"><a><b>Contact Number</b></a></td><td><input type="text" style="font-size: 16px; border: none; background-color: #a3ffce; height:20%;" name="contactnumber" value="<?php echo $rowq1['contact_number'];?>"></td></tr>
			<tr><td style="width:200px;"><a><b>Email</b></a></td><td><input type="text" style="font-size: 16px; border: none; background-color: #a3ffce; height:20%;" name="email" value="<?php echo $rowq1['email'];?>"></td></tr>
			<tr><td style="width:200px;"><a><b>Post</b></td></a><td><select size="1" name="postid" style="width: 200px; font-size: 16px; border: none; background-color: #a3ffce; height:20%;">
			<?php 
			// fill post drop box with department names
			$qrypost = mysqli_query($connection, "SELECT * from post") or die(mysqli_error($connection));
			while ($line = mysqli_fetch_array($qrypost, MYSQLI_ASSOC)) 
			{ 
				echo "<option value='" . $line['post_id'] . "'";
				if($line['post_id'] == $rowq1['post_id'])
					echo " selected='selected' ";
			
				echo ">"; 
				echo $line['post_name'] . "</option>"; 
			} 
			?></td>
			<tr><td style="width:200px;"><a><b>Department</b></td></a><td><select size="1" name="departmentid" style="width: 200px; font-size: 16px; border: none; background-color: #a3ffce; height:20%;">
			<?php 
			// fill department drop box with department names
			$qrydepartment = mysqli_query($connection, "SELECT * from department") or die(mysqli_error($connection));
			while ($line = mysqli_fetch_array($qrydepartment, MYSQLI_ASSOC)) 
			{ 
				echo "<option value='" . $line['department_id'] . "'";
				if($line['department_id'] == $rowq1['department_id'])
					echo " selected='selected' ";
			
				echo ">"; 
				echo $line['department_name'] . "</option>"; 
			} 
			?></td></tr>
			<tr><td style="width:200px;"><a><b>Access Right</b></td></a><td><select size="1" name="accessrightid" style="width: 200px; font-size: 16px; border: none; background-color: #a3ffce;">
			<?php 
			// fill gender list box with department names
			$qryaccess = mysqli_query($connection, "SELECT * from accessright") or die(mysqli_error($connection));
			while ($line = mysqli_fetch_array($qryaccess, MYSQLI_ASSOC)) 
			{ 
				echo "<option value='" . $line['accessright_id'] . "'";
				if($line['accessright_id'] == $rowq1['accessright_id'])
					echo " selected='selected' ";
			
				echo ">"; 
				echo $line['accessright_name'] . "</option>"; 
			} 
			?></td>
			<tr><td style="width:200px;"><a><b>Username</b></a></td><td><input type="text" style="font-size: 16px; border: none; background-color: #a3ffce; height:20%;" name="username" value="<?php echo $rowq1['username'];?>"></td></tr>
			<tr><td style="width:200px;" colspan="2"><a><b></b></a></td></tr>
			<tr><td colspan = "2" style="width: 200px;"><input type="submit" value="Save Changes" name="submit" style="margin-left: 200px; background-color:#008080; text-align: center; font-size: 14px; border-radius: 12px; padding: 2px; width: 15%; color: white; cursor: pointer;"/>
		</table>
	</div>
	<?php db_connection_close(); ?>	
</body>
</html>
