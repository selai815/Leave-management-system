<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	require_once("../includes/db_connection.php");
	session();
	checkinactivity();
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
	</head>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	<form id="deptaddform" method="post" action="deptadd.php">
	
	<div class = "maincontent">
		<h2>Add New Department</h2>
		<table id="tblprofile">
			<tr><td style="width:200px;"><a><b>Department Name</b></a></td><td><input type="text"  name="deptname" placeholder="Enter Department Name" style="width:100%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required/></td></tr>
			<tr><td style="width:200px;"><a><b>Department Description</b></a></td><td><input type="text" name="deptdesc" placeholder="Enter Department Description" style="width:100%; font-size: 16px; border: none; background-color: #a3ffce; height:20%;" required/></td></tr>
			<tr><td colspan = "2" style="width: 200px;"><input type="submit" value="Add Department" name="submit" style="margin-left: 120px; background-color:#008080; text-align: center; font-size: 14px; border-radius: 12px; padding: 2px; width: 15%; color: white; cursor: pointer;"/>
			<input type="reset" value="CLEAR" name="clear" style="margin-left: 100px; background-color:#008080; text-align: center; font-size: 14px; border-radius: 12px;  padding: 2px; width: 15%; color: white; cursor: pointer;" />
			
		</table>
	</div>
	<!--<script src="src/js/main.js"></script>-->
</body>
</html>
