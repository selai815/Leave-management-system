<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	//echo $_SESSION['empid'];
	$empnum = $_SESSION['empid'];
	checkinactivity();
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
	</head>
<?php 
	// include the file that defines (contains) the username and password
	require_once("../includes/db_connection.php");
	//connect to your mysql database
	
	//checking if general manager
	$qry ="Select post_id from vi_employee WHERE employee_id='$empnum'";
	$res = mysqli_query($connection, $qry) or die(mysqli_error($connection));
	$row = mysqli_fetch_assoc($res);
	
	if ($row['post_id'] != 8){  //CHECK IF USER IS GENERAL MANAGER
		//retrieve employee record
		$query = "SELECT * FROM vi_employee WHERE supervisor_id ='".$_SESSION['empid']."' ORDER BY last_name, first_name" ;
	}
	else{
		$query = "SELECT * FROM vi_employee ORDER BY last_name, first_name" ;
	}
	$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
	//recordset retrieved
	//confirm_query($result);
	
?>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	<div class = "maincontent">
		<h2>Employee List</h2>
		<table class = "table" id="tblform">
			<thead>
				<tr><td><a><b>Emp. ID</b></b></td>
					<td><a><b>Name</b></a></td>
					<td><a><b>Gender</b></a></td>
					<td><a><b>Date Hired</b></a></td>
					<td><a><b>Post</b></a></td>
					<td><a><b>Department</b></a></td>
					
					<td><a><d>Leave Taken</d></a></td>
				</tr>			
			</thead>
			<tbody>
			<?php
				$i = 0;
				$mess = "No Record found!";
				
				if($result->num_rows > 0){
					while ($line=mysqli_fetch_assoc($result)){
						echo "<tr><td><center>";
						echo "<a href =profile.php?empnum=" .$line['employee_id'].">".$line['employee_id']."</a></center></td>";
						echo "<td>".$line['last_name'].", ".$line['first_name']. "</td>";
						echo "<td>".$line['gender_name']."</td>";
						echo "<td>".date("d-m-Y", strtotime($line['date_hired']))."</td>";
						echo "<td>".$line['post_name']."</td>";
						echo "<td>".$line['department_name']."</td>";
						
						echo "<td style='font-size=14px; font-color: #052efa;'><a href =reportleavebyemp.php?empnum=" .$line['employee_id'].">View</a></center></td>";
						echo "</tr>";
						$i++;	
					}
				}
				else
				{					
					echo "<tr><td>". $mess . "</td></tr>";
				}	
			?>
			</tbody>
		</table>
	</div>
	
	<!--<script src="src/js/main.js"></script>-->
	<?php db_connection_close();?>
	</body>
</html>

