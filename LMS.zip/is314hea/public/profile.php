<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	//echo $_SESSION['empid'];
	checkinactivity();
		
	$empid="";
	if (!empty($_GET)){
		$empid = $_GET['empnum'];
	}
	Else{
		$empid = $_SESSION['empid']; 
	}
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
	</head>
<?php 
		
	// include the file that defines (contains) the username and password
	//require('functions.inc.php');
	require_once("../includes/db_connection.php");
	//connect to your mysql database
	$query1 = "SELECT * FROM vi_employee WHERE employee_id ='$empid'";
	$query2 = "SELECT employee_id,employeename,
				SUM(IF(leavetype_id=1, LeaveBalance, NULL)) AS Casual,
				SUM(IF(leavetype_id=2, LeaveBalance, NULL)) AS Bereavement,
				SUM(IF(leavetype_id=3, LeaveBalance, NULL)) AS Sick,
				SUM(IF(leavetype_id=4, LeaveBalance, NULL)) AS Maternity,
				SUM(IF(leavetype_id=5, LeaveBalance, NULL)) AS Vacation
				FROM vi_leavebalance WHERE employee_id ='$empid'";
	
	$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
	$result2 = mysqli_query($connection, $query2) or die(mysqli_error($connection));
	//$count = mysqli_num_rows($result1);
	$rowq1 = mysqli_fetch_assoc($result1);
	$rowq2 = mysqli_fetch_assoc($result2);
	//echo time();//$starttime;
	//$casual
	
?>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	<div class = "maincontent">
		<h2>Employee Profile</h2>
		<table id="tblprofile">
			<tr><td style="width:200px;"><a><b>Employee ID</b></a></td><td><?php echo $empid; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Name</b></a></td><td><?php echo $rowq1['first_name']." ". $rowq1['last_name']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Gender</b></a></td><td><?php echo $rowq1['gender_name']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Date of Birth</b></a></td><?php 
			$date = ""; 
			if (is_null($rowq1['dob']))
			{
				$date = "";
			}
			else 
			{
				$date = date('d-m-Y', strtotime($rowq1['dob']));
			}
			echo "<td>" .$date. "</td>";
			?></tr>
			<tr><td style="width:200px;"><a><b>Contact Number</b></td></a><td><?php echo $rowq1['contact_number']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Email</b></a></td><td><?php echo $rowq1['email']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Date Hired</b></a></td>
			<?php
				$date = ""; 
				if (is_null($rowq1['date_hired']))
				{
					$date = "";
				}
				else 
				{
					$date = date('d-m-Y', strtotime($rowq1['date_hired']));
				}
				echo "<td>" .$date. "</td>";
			?></tr>
			<tr><td style="width:200px;"><a><b>Post</b></a></td><td><?php echo $rowq1['post_name']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Department</b></td></a><td><?php echo $rowq1['department_name']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Access Rights</b></a></td><td><?php echo $rowq1['accessright_name']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Reports To</b></td></a><td><?php echo $rowq1['ReportsTo']; ?></td></tr>
			
			<tr><td colspan = "2" style="width:200px;"><a><b>LEAVE BALANCE IN DAYS, AS OF TODAY</b></a></td></tr>
			<tr><td style="width:200px;"><a><b>Casual</b></a></td><td><?php echo $rowq2['Casual']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Bereavement</b></a></td><td><?php echo $rowq2['Bereavement']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Sick</b></a></td><td><?php echo $rowq2['Sick']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Maternity</b></a></td><td><?php echo $rowq2['Maternity']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Vacation</b></td></a><td><?php echo $rowq2['Vacation']; ?></td></tr>
			<tr><td colspan="2"></td></tr>
			<tr><td colspan="2"><input type="button" value="BACK!" onclick="history.back()"></td></tr>
		</table>
	</div>
	<!--<script src="src/js/main.js"></script>-->
</body>
</html>
