<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	//echo $_SESSION['empid'];
	checkinactivity();
	
	$requestnum=$_GET['requestnum'];
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
	</head>
<?php 
		
	
	// include the file that defines (contains) the connection to the mysql database
	require_once("../includes/db_connection.php");
	//connect to your mysql database
	
	$query1 = "Select vi_leaverequest. *, employee.first_name AS givname, employee.last_name as famname FROM vi_leaverequest, employee WHERE leaverequest_id='$requestnum' AND employee.employee_id = vi_leaverequest.approvingofficer_id";
		
	$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
	$rowq1 = mysqli_fetch_assoc($result1);
	
	
?>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	<div class = "maincontent">
		<h2>Leave Details</h2>
		<table id="tblprofile">
			<tr><td style="width:200px;"><a><b>Leave Request ID</b></a></td><td><?php echo $rowq1['leaverequest_id']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Name</b></a></td><td><?php echo $rowq1['employeename']; ?></td></tr>
			<tr style="display:none"><td style="width:200px;"><a><b>Leave Type ID</b></a></td><td><?php echo $rowq1['leavetype_id']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Leave Type</b></a></td><td><?php echo $rowq1['leavetype_name']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Start Date</b></a><?php echo "<td>" .date("d-m-Y", strtotime($rowq1['startdate']))."</td>";?></tr>
			<tr><td style="width:200px;"><a><b>End Date</b></td></a><?php echo "<td>" .date("d-m-Y", strtotime($rowq1['enddate']))."</td>";?></tr>
			<tr><td style="width:200px;"><a><b>Total Days</b></td></a><td><?php echo $rowq1['totaldays']; ?></td></tr>
			<tr style="height: 20px;"><td style="width:200px;"><a><b>Justification</b></a></td><td><?php echo $rowq1['justification']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Application Date</b></td></a><?php echo "<td>" .date("d-m-Y", strtotime($rowq1['application_date']))."</td>";?></tr>
			<tr style="display:none"><td style="width:200px;"><a><b>Decision ID</b></a></td><td><?php echo $rowq1['decision_id'];?></td></tr>
			<tr><td style="width:200px;"><a><b>Status</b></a></td><td><?php echo $rowq1['decision_name'];?></td></tr>
			<tr><td style="width:200px;"><a><b>Date Decided</b></a>
			<?php
			$date = ""; 
			if (is_null($rowq1['decision_date']))
			{
				$date = "Awaits Decision";
			}
			else 
			{
				$date = date('d-m-Y', strtotime($rowq1['decision_date']));
			}
			echo "<td>" .$date. "</td>";
			?></tr>
			<tr><td style="width:200px;"><a><b>Comment</b></a></td><td><?php echo $rowq1['comments']; ?></td></tr>
			<tr style="display:none"><td style="width:200px;"><a><b>Approving Officer ID</b></a></td><td><?php echo $rowq1['approvingofficer_id']; ?></td></tr>
			<tr><td style="width:200px;"><a><b>Approving Officer</b></a></td><td><?php echo $rowq1['givname']." ".$rowq1['famname']; ?></td></tr>
			<tr><td style="width:200px;" colspan="2"><a><b></b></a></td></tr>
			<tr><td colspan = "2" style="width: 200px;"><input type="button" value="BACK" onclick="history.back()"></td></tr>
		</table>
	</div>
	<!--<script src="src/js/main.js"></script>-->
</body>
</html>
