<?php
	// start session
	session_start();
	
	// clear array contents and destroy session
	unset($_SESSION['empno']);
	session_destroy();
	
	// open home page.
	header("Location: ./logout.php");
	
?>
