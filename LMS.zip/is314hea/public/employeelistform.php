<!DOCTYPE html>
<?php
	session_start();
	require_once("../includes/functions.php");
	//require_once("../includes/db_connection.php");
	session();
	
	checkinactivity();
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"><html>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="src/css/style.css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="src/css/mainstyle.css" rel="stylesheet">
		<title>Supermarket 6</title>
	</head>
<?php 
	// include the file that defines (contains) the username and password
	require_once("../includes/db_connection.php");
	//connect to your mysql database
	
	//retrieve employee record
	
	$query = "SELECT * FROM vi_employee ORDER BY date_hired DESC";
	$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
	//recordset retrieved
	//confirm_query($result);
	
?>
	<div class="header">
		<div class = "logo">Supermarket 6: <?php echo $_SESSION['fname']." ". $_SESSION['lname']; ?></div>
		<!-- part of header -->
		<div style="float:right; margin-top: -70px; margin-right: 10px;">
		
              <i class="fa fa-home" style ="color:white; font-size: 20px; margin-left:80px;"><a href="welcome.php" style="color:white; margin-left:5px;display:in-line; font-size:17px; margin-right: 8px; text-decoration:none;">Home</a></i>
		       <i class="fa fa-cog" style="margin-right:-40px; color: white; font-size: 17px;" ><a href="passwordmineresetform.php" style="color:white; margin-left:5px;display:in-line; margin-right: 10px; font-size: 17px; text-decoration:none;">Reset Password</a></i>
	   </div>
	
	</div>
	<body>
	<?php 
		include_once($_SESSION['navifile']);
	?>
	<div class = "maincontent">
		<h2>Employee List</h2>
		<form action="employeeaddform.php"><input type="submit" style="margin-top: 10px; height: 30px; font-size: 14px; hover: pointer;" value="ADD EMPLOYEE" /></form>
		<table class = "table" id="tblform">
			<thead>
				<tr><td><a><b>Employee ID.</b></b></td>
					<td><a><b>Employee Name</b></a></td>
					<td><a><b>Date Hired</b></a></td>
					<td><a><b>Post</b></a></td>
					<td><a><b>Department</b></a></td>
					<td><a><b>Email</b></a></td>
					<td><a><b>Supervisor</b></a></td>
					<td><a><d>Reset Password</d></a></td>
				</tr>			
			</thead>
			<tbody>
			<?php
				$i = 0;
				$mess = "No leave record";
				
				if($result->num_rows > 0){
					while ($line=mysqli_fetch_assoc($result)){
						echo "<tr><td><center>";
						echo "<a href =employeeupdateform.php?empnum=" .$line['employee_id'].">".$line['employee_id']."</a></center></td>";
						echo "<td>".$line['first_name']." ".$line['last_name']. "</td>";
						echo "<td>".date("d-m-Y", strtotime($line['date_hired']))."</td>";
						echo "<td>".$line['post_name']."</td>";
						echo "<td>".$line['department_name']."</td>";
						echo "<td>".$line['email']."</td>";
						echo "<td>".$line['ReportsTo']."</td>";
						echo "<td style='font-size=14px; font-color: #052efa;'><a href =passwordempresetform.php?empnum=" .$line['employee_id'].">Reset</a></center></td>";
						echo "</tr>";
						$i++;	
					}
				}
				else
				{					
					echo "<tr><td>". $mess . "</td></tr>";
				}	
			?>
				
			</tbody>
		</table>
	</div>
	
	<!--<script src="src/js/main.js"></script>-->
	<?php db_connection_close();?>
	</body>
</html>

